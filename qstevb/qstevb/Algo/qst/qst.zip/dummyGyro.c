#include <stdio.h>
#include <stdlib.h>
//#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <string.h>

#include "dummyGyro.h"
#include "qstLog.h"

//#define DUMMYGYRO_LOG


struct virtual_gyro_matrix matrix_old = {{
    {1.0, 0.0, 0.0}, 
    {0.0, 1.0, 0.0}, 
    {0.0, 0.0, 1.0},
    }};
struct virtual_gyro_matrix matrix_new = {{
    {1, 0, 0}, 
    {0, 1, 0}, 
    {0, 0, 1},
    }};
struct virtual_gyro_matrix qst_matrix_transpose = {{
    {1, 0, 0},
    {0, 1, 0}, 
    {0, 0, 1},
    }};
static int64_t timeStamp_old = 0;

#define    THRESH_ZERO (5 / RadToDeg)  //小于2度，虚拟陀螺仪输出零
#define    THRESH_Z_ZERO (8 / RadToDeg)  //小于2度，虚拟陀螺仪输出零

float Vgyro_last[3] = {0, 0, 0};
unsigned char accel_init = 0;
#ifdef USING_BW_FILTER
typedef struct
{
    float a1;
    float a2;
    float b0;
    float b1;
    float b2;
}QST_Filter_Parameter;

typedef struct
{
    float _delay_element_1;
    float _delay_element_2;
}QST_Filter_Buffer;
#endif

#if 0 //def USING_BW_FILTER
//2hz
static QST_Filter_Parameter mag_filter_parameter = {-1.64745998107698,0.700896781188403,0.0133592000278565,0.0267184000557130,0.0133592000278565};
//2hz
static QST_Filter_Parameter accel_filter_parameter = {-1.64745998107698,0.700896781188403,0.0133592000278565,0.0267184000557130,0.0133592000278565};
//2hz
static QST_Filter_Parameter gyro_filter_parameter = {-1.64745998107698,0.700896781188403,0.0133592000278565,0.0267184000557130,0.0133592000278565};

QST_Filter_Buffer mag_filter_buffer[3] = {{0,0}};
QST_Filter_Buffer accel_filter_buffer[3] = {{0,0}};
QST_Filter_Buffer gyro_filter_buffer[3] = {{0,0}};
#endif

#ifdef USING_BW_FILTER 
static float Filter_Apply(float sample, QST_Filter_Buffer *buffer, QST_Filter_Parameter *filter)
{
    //do the filtering
    float delay_element_0 = sample - buffer->_delay_element_1 * filter->a1 - buffer->_delay_element_2 * filter->a2;

    const float output = delay_element_0 * filter->b0 + buffer->_delay_element_1 * filter->b1 + buffer->_delay_element_2 * filter->b2;

    buffer->_delay_element_2 = buffer->_delay_element_1;
    buffer->_delay_element_1 = delay_element_0;

    //return the value. Should be no need to check limits
    return output;
}
#else
#define Window_Accel_N 40
#define Window_Mag_N 40
#define Window_Gyro_N 40
float accel_buffet_x[Window_Accel_N];
float accel_buffet_y[Window_Accel_N];
float accel_buffet_z[Window_Accel_N];
static void Filter_Window_Accel_init(float *sample)
{
    unsigned char axis = 0;
    for(axis = 0; axis < Window_Accel_N; axis++)
    {
        accel_buffet_x[axis] = sample[0];  
        accel_buffet_y[axis] = sample[1];
        accel_buffet_z[axis] = sample[2];
    }
}

static void Filter_Window_Accel(float *sample, float *filter)
{
    unsigned char axis = 0;
    float sum_x = 0;
    float sum_y = 0;
    float sum_z = 0;
    for(axis = 0; axis < Window_Accel_N - 1; axis++)
    {
        accel_buffet_x[axis] = accel_buffet_x[axis + 1];   
        sum_x += accel_buffet_x[axis];
        accel_buffet_y[axis] = accel_buffet_y[axis + 1];   
        sum_y += accel_buffet_y[axis];
        accel_buffet_z[axis] = accel_buffet_z[axis + 1];   
        sum_z += accel_buffet_z[axis];
    }
    accel_buffet_x[axis] = sample[0];   
    sum_x += accel_buffet_x[axis];
    filter[0] = sum_x / Window_Accel_N;
    accel_buffet_y[axis] = sample[1];   
    sum_y += accel_buffet_y[axis];
    filter[1] = sum_y / Window_Accel_N;
    accel_buffet_z[axis] = sample[2];   
    sum_z += accel_buffet_z[axis];
    filter[2] = sum_z / Window_Accel_N;
}

float mag_buffet_x[Window_Mag_N];
float mag_buffet_y[Window_Mag_N];
float mag_buffet_z[Window_Mag_N];
static void Filter_Window_Mag_init(float *sample)
{
    unsigned char axis = 0;
    for(axis = 0; axis < Window_Mag_N; axis++)
    {
        mag_buffet_x[axis] = sample[0];  
        mag_buffet_y[axis] = sample[1];
        mag_buffet_z[axis] = sample[2];
    }
}

static void Filter_Window_Mag(float *sample, float *filter)
{
    unsigned char axis = 0;
    float sum_x = 0;
    float sum_y = 0;
    float sum_z = 0;
    for(axis = 0; axis < Window_Mag_N - 1; axis++)
    {
        mag_buffet_x[axis] = mag_buffet_x[axis + 1];   
        sum_x += mag_buffet_x[axis];
        mag_buffet_y[axis] = mag_buffet_y[axis + 1];   
        sum_y += mag_buffet_y[axis];
        mag_buffet_z[axis] = mag_buffet_z[axis + 1];   
        sum_z += mag_buffet_z[axis];
    }
    mag_buffet_x[axis] = sample[0];   
    sum_x += mag_buffet_x[axis];
    filter[0] = sum_x / Window_Mag_N;    
    mag_buffet_y[axis] = sample[1];   
    sum_y += mag_buffet_y[axis];
    filter[1] = sum_y / Window_Mag_N;
    mag_buffet_z[axis] = sample[2];   
    sum_z += mag_buffet_z[axis];
    filter[2] = sum_z / Window_Mag_N;
}

float gyro_buffet_x[Window_Gyro_N];
float gyro_buffet_y[Window_Gyro_N];
float gyro_buffet_z[Window_Gyro_N];

static void Filter_Window_Gyro_init(float *sample)
{
    unsigned char axis = 0;
    for(axis = 0; axis < Window_Gyro_N; axis++)
    {
        gyro_buffet_x[axis] = sample[0];  
        gyro_buffet_y[axis] = sample[1];
        gyro_buffet_z[axis] = sample[2];
    }
}

static void Filter_Window_Gyro(float *sample, float *filter)
{
    unsigned char axis = 0;
    float sum_x = 0;
    float sum_y = 0;
    float sum_z = 0;
    for(axis = 0; axis < Window_Gyro_N - 1; axis++)
    {
        gyro_buffet_x[axis] = gyro_buffet_x[axis + 1];   
        sum_x += gyro_buffet_x[axis];
        gyro_buffet_y[axis] = gyro_buffet_y[axis + 1];   
        sum_y += gyro_buffet_y[axis];
        gyro_buffet_z[axis] = gyro_buffet_z[axis + 1];   
        sum_z += gyro_buffet_z[axis];
    }
    gyro_buffet_x[axis] = sample[0];   
    sum_x += gyro_buffet_x[axis];
    filter[0] = sum_x / Window_Gyro_N;   
    gyro_buffet_y[axis] = sample[1];   
    sum_y += gyro_buffet_y[axis];
    filter[1] = sum_y / Window_Gyro_N;
    gyro_buffet_z[axis] = sample[2];   
    sum_z += gyro_buffet_z[axis];
    filter[2] = sum_z / Window_Gyro_N;
}
#endif

static void Qst_matrix_T(struct virtual_gyro_matrix *a, struct virtual_gyro_matrix *aT, int num)
{
    //struct virtual_gyro_matrix ori;
    int i = 0, j = 0;

    for(i = 0; i < num; i++)
    {
        for(j = 0; j < num; j++)
        {
            aT->cs[i][j] = a->cs[j][i];
        }
    }
#if 0//def DUMMYGYRO_LOG
    D("%s, %f, %f, %f, %f, %f, %f, %f, %f, %f\n",__func__,
        aT->cs[0][0], aT->cs[0][1], aT->cs[0][2],
        aT->cs[1][0], aT->cs[1][1], aT->cs[1][2],
        aT->cs[2][0], aT->cs[2][1], aT->cs[2][2]);
#endif
}

void Qst_vgyro_matrix(float *Acc, float *Mag, struct virtual_gyro_matrix *matrix)
{
    float C[3][3] = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
    float hx_mag = 0, hy_mag = 0, hz_mag = 0;
    float cosyaw = 0, sinyaw = 0, hx_C = 0, hy_C = 0, hz_C = 0;
    float normalize = sqrtf(Acc[0] * Acc[0] + Acc[1] * Acc[1] + Acc[2] * Acc[2]);
    C[2][0] = Acc[0] / normalize;
    C[2][1] = Acc[1] / normalize;
    C[2][2] = Acc[2] / normalize;

    if(fabs(C[2][0]) > 0.5)
    {
        C[1][0] = C[2][1];
        C[1][1] = -C[2][0];
        C[1][2] = 0;
    }
    else
    {
        C[1][0] = 0;
        C[1][1] = C[2][2];
        C[1][2] = -C[2][1];
    }
    //归一化
    normalize = sqrtf(C[1][0] * C[1][0] + C[1][1] * C[1][1]+ C[1][2] * C[1][2]);        
    C[1][0] = C[1][0] / normalize;
    C[1][1] = C[1][1] / normalize;
    C[1][2] = C[1][2] / normalize;

    //做叉积求C0(第一行)
    C[0][0] = C[1][1] * C[2][2] - C[2][1] * C[1][2];
    C[0][1] = -(C[1][0] * C[2][2] - C[2][0] * C[1][2]);
    C[0][2] = C[1][0] * C[2][1] - C[2][0] * C[1][1];

    normalize = sqrtf(Mag[0] * Mag[0] + Mag[1] * Mag[1] + Mag[2] * Mag[2]);
    hx_mag = Mag[0] / normalize;
    hy_mag = Mag[1] / normalize;
    hz_mag = Mag[2] / normalize;

    //地磁矢量
    hx_C = C[0][0] * hx_mag + C[0][1] * hy_mag + C[0][2] * hz_mag;
    hy_C = C[1][0] * hx_mag + C[1][1] * hy_mag + C[1][2] * hz_mag;
    hz_C = C[2][0] * hx_mag + C[2][1] * hy_mag + C[2][2] * hz_mag;
    
    sinyaw = hx_C / sqrtf(hx_C * hx_C + hy_C * hy_C);
    cosyaw = hy_C / sqrtf(hx_C * hx_C + hy_C * hy_C);

    if(sinyaw <= -1.0f)
    {
        sinyaw = -1;
    }
    else if(sinyaw >= 1.0f)
    {
        sinyaw = 1;
    }
    if(cosyaw <= -1.0)
    {
        cosyaw = -1;
    }
    else if(cosyaw >= 1.0f)
    {
        cosyaw = 1;
    }
    //Cnb = Cnh * Chb
    matrix->cs[0][0] = cosyaw * C[0][0] - sinyaw * C[1][0];
    matrix->cs[0][1] = cosyaw * C[0][1] - sinyaw * C[1][1];
    matrix->cs[0][2] = cosyaw * C[0][2] - sinyaw * C[1][2];

    matrix->cs[1][0] = sinyaw * C[0][0] + cosyaw * C[1][0];
    matrix->cs[1][1] = sinyaw * C[0][1] + cosyaw * C[1][1];
    matrix->cs[1][2] = sinyaw * C[0][2] + cosyaw * C[1][2];

    matrix->cs[2][0] = C[2][0];
    matrix->cs[2][1] = C[2][1];
    matrix->cs[2][2] = C[2][2];
}


//void Qst_dummy_gyro(float *Acc, float *Mag, float *Vgyro, int64_t timeStamp)
void QST_fussion_PG(float *Acc, float *Mag, float *Vgyro, int64_t timeStamp)
{
    int i = 0, j = 0, x = 0;
    float acc_data[3] = {0, 0, 0};
    float mag_data[3] = {0, 0, 0};
    float gyro_data[3] = {0, 0, 0};
#if 0
    float vgyro_output[3] = {0, 0, 0};
#endif

    float T_delta = (timeStamp - timeStamp_old) / 1000000000.0f;
    float acc_nomal = 0;
    float mag_nomal = 0;
    unsigned char vgyro_init = 0;

    if(T_delta < 0 || T_delta > 0.2f)
    {
        T_delta = 0.02f;
        accel_init = 0;
    }
    if(T_delta == 0){
        Vgyro[0] = 0;
        Vgyro[1] = 0;
        Vgyro[2] = 0;
        return;
    }

    struct virtual_gyro vgyro_euler;
    struct virtual_gyro_matrix matrix_fin;
    memset(&vgyro_euler, 0, sizeof(struct virtual_gyro));
    memset(&matrix_fin, 0, sizeof(struct virtual_gyro_matrix));
    //D("%s: T_delta:%f\n", __func__, T_delta);
    //D("xuni_gyro1 %f, %f, %f, %f, %f, %f\n", Acc[0], Acc[1], Acc[2], Mag[0], Mag[1], Mag[2]);

    acc_nomal = sqrtf(Acc[0] * Acc[0] + Acc[1] * Acc[1] + Acc[2] * Acc[2]);
    mag_nomal = sqrtf(Mag[0] * Mag[0] + Mag[1] * Mag[1] + Mag[2] * Mag[2]);
    
    if((acc_nomal > 1.0f) && (mag_nomal > 1.0f))
    {
#if 0 //def USING_BW_FILTER
        if(accel_init == 0){
            accel_filter_buffer[axis]._delay_element_1 = Acc[axis];
            accel_filter_buffer[axis]._delay_element_2 = Acc[axis];
            mag_filter_buffer[axis]._delay_element_1 = Mag[axis];
            mag_filter_buffer[axis]._delay_element_2 = Mag[axis];
        }
        acc_data[axis] = Filter_Apply(Acc[axis], &accel_filter_buffer[axis], &accel_filter_parameter);
        mag_data[axis] = Filter_Apply(Mag[axis], &mag_filter_buffer[axis], &mag_filter_parameter);
#else
        if(accel_init == 0)
        {
            Filter_Window_Accel_init(Acc);
            Filter_Window_Mag_init(Mag);
            Filter_Window_Gyro_init(gyro_data);
            accel_init = 1;
        }
        Filter_Window_Accel(Acc, acc_data);
        Filter_Window_Mag(Mag, mag_data);
#endif

#ifdef DUMMYGYRO_LOG
   D("%s,xuni_mag %f, %f, %f\n", __func__, mag_data[0], mag_data[1], mag_data[2]);
   D("%s,xuni_gyro1 %f, %f, %f\n", __func__, vgyro_euler.pitch, vgyro_euler.roll, vgyro_euler.yaw);
   D("%s,xuni_gyro1 %f, %f, %f, %f, %f, %f\n", __func__, acc_data[0], acc_data[1], acc_data[2], mag_data[0], mag_data[1], mag_data[2]);
#endif

        vgyro_euler.timeStamp = timeStamp;
        Qst_vgyro_matrix(acc_data, mag_data, &matrix_new);

#ifdef DUMMYGYRO_LOG
    D("%s,xuni_gyro1 %f, %f, %f, %f, %f, %f, %f, %f, %f\n", __func__,
      matrix_new.cs[0][0], matrix_new.cs[0][1], matrix_new.cs[0][2],
      matrix_new.cs[1][0], matrix_new.cs[1][1], matrix_new.cs[1][2],
      matrix_new.cs[2][0], matrix_new.cs[2][1], matrix_new.cs[2][2]);
#endif

        Qst_matrix_T(&matrix_new, &qst_matrix_transpose, 3);
            
        for(i = 0; i < 3; i++) 
        {
            for(j = 0; j < 3; j++) 
            {
                for(x = 0; x < 3; x++) 
                {
                    matrix_fin.cs[i][j] += qst_matrix_transpose.cs[i][x] * matrix_old.cs[x][j];
                }
            }
        }
        matrix_fin.cs[0][0] = matrix_fin.cs[0][0] - 1;
        matrix_fin.cs[1][1] = matrix_fin.cs[1][1] - 1;
        matrix_fin.cs[2][2] = matrix_fin.cs[2][2] - 1;

#ifdef DUMMYGYRO_LOG
    D("%s,xuni_gyro1 %f, %f, %f, %f, %f, %f, %f, %f, %f\n", __func__,
      matrix_fin.cs[0][0], matrix_fin.cs[0][1], matrix_fin.cs[0][2],
      matrix_fin.cs[1][0], matrix_fin.cs[1][1], matrix_fin.cs[1][2],
      matrix_fin.cs[2][0], matrix_fin.cs[2][1], matrix_fin.cs[2][2]);
    D("%s,xuni_gyro1: %f,%f,%f,%f,%f\n", __func__, matrix_fin.cs[2][1], matrix_fin.cs[1][2], matrix_fin.cs[0][2], matrix_fin.cs[2][0], T_delta);
#endif
        gyro_data[0] = -(matrix_fin.cs[2][1] - matrix_fin.cs[1][2]) / (2 * T_delta);
        gyro_data[1] = -(matrix_fin.cs[0][2] - matrix_fin.cs[2][0]) / (2 * T_delta);
        gyro_data[2] = -(matrix_fin.cs[1][0] - matrix_fin.cs[0][1]) / (2 * T_delta);

#ifdef DUMMYGYRO_LOG
    D("%s,xuni_gyro2: %f,%f,%f,%f\n", __func__, gyro_data[0], gyro_data[1], gyro_data[2], T_delta);
#endif

#ifdef USING_BW_FILTER
    if(init_counter > 4)
    {
        for(axis = 0; axis < 3; axis++)
        {
            vgyro_output[axis] = Filter_Apply(gyro_data[axis], &gyro_filter_buffer[axis], &gyro_filter_parameter);
        }
    }
    else
    {
        for(axis = 0; axis < 3; axis++)
        {
            vgyro_output[axis] = 0;
        }
    }
#endif

        matrix_old = matrix_new;
        timeStamp_old = timeStamp;
#if 0 //def USING_BW_FILTER
    Vgyro[0] = vgyro_output[0];
    Vgyro[1] = vgyro_output[1];
    Vgyro[2] = vgyro_output[2];
#else
    
        Filter_Window_Gyro(gyro_data, Vgyro);
        float gyro_normal = sqrtf(gyro_buffet_x[0] * gyro_buffet_x[0] + gyro_buffet_y[0] * gyro_buffet_y[0] 
            + gyro_buffet_z[0] * gyro_buffet_z[0]);
        
        if(gyro_normal > (float)1e-7)
        {
            vgyro_init = 1;
        }
        if(vgyro_init == 0)
        {
            Vgyro[0] = 0;
            Vgyro[1] = 0;
            Vgyro[2] = 0;
        }
        
        if(fabs(Vgyro[0]) < THRESH_ZERO)
        {
            Vgyro[0] = Vgyro[0] * 0.1f; 
        }
        if(fabs(Vgyro[1]) < THRESH_ZERO)
        {
            Vgyro[1] = Vgyro[1] * 0.1f; 
        }
        if(fabs(Vgyro[2]) < THRESH_Z_ZERO)
        {
            Vgyro[2] = Vgyro[2] * 0.1f; 
        }
    
        Vgyro_last[0] = Vgyro[0];
        Vgyro_last[1] = Vgyro[1];
        Vgyro_last[2] = Vgyro[2];
    }
    else
    {
        Vgyro[0] = Vgyro_last[0];
        Vgyro[1] = Vgyro_last[1];
        Vgyro[2] = Vgyro_last[2];
    }
#endif
#ifdef DUMMYGYRO_LOG
    D("xuni_buffer: %f,%f,%f\n", gyro_filter_buffer[0]._delay_element_1, gyro_filter_buffer[1]._delay_element_1, gyro_filter_buffer[2]._delay_element_1);
        D("xuni_buffer: %f,%f,%f\n", gyro_filter_buffer[0]._delay_element_2, gyro_filter_buffer[1]._delay_element_2, gyro_filter_buffer[2]._delay_element_2);
    D("xuni_gyro: %f,%f,%f,%f\n", vgyro_output[0], vgyro_output[1], vgyro_output[2], T_delta);
#endif
}
