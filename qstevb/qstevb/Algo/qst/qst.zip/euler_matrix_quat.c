
#include <stdio.h>
#include <math.h>
#include "euler_matrix_quat.h"

#ifndef PI
#define PI					3.14159265358979f
#endif
#define RADTODEG			(180.0f/PI)
#define DEGTORAD			(PI/180.0f)

#define clamp(v) ((v) < 0 ? 0 : (v))

void qst_quat_to_matrix(float quat[4], float matrix[9])
{
//	float R[3][3];
    float q0 = quat[3];	// w
    float q1 = quat[0];	// x
    float q2 = quat[1];	// y
    float q3 = quat[2];	// z
    float sq_q1 = 2 * q1 * q1;
    float sq_q2 = 2 * q2 * q2;
    float sq_q3 = 2 * q3 * q3;
    float q1_q2 = 2 * q1 * q2;
    float q3_q0 = 2 * q3 * q0;
    float q1_q3 = 2 * q1 * q3;
    float q2_q0 = 2 * q2 * q0;
    float q2_q3 = 2 * q2 * q3;
    float q1_q0 = 2 * q1 * q0;

    matrix[0] = 1 - sq_q2 - sq_q3;
    matrix[1] = q1_q2 - q3_q0;
    matrix[2] = q1_q3 + q2_q0;
    matrix[3] = q1_q2 + q3_q0;
    matrix[4] = 1 - sq_q1 - sq_q3;
    matrix[5] = q2_q3 - q1_q0;
    matrix[6] = q1_q3 - q2_q0;
    matrix[7] = q2_q3 + q1_q0;
    matrix[8] = 1 - sq_q1 - sq_q2;
}

void qst_quat_to_euler(float quat[4], float euler[3])
{
	float R[3][3];
    float q0 = quat[3];	// w
    float q1 = quat[0];	// x
    float q2 = quat[1];	// y
    float q3 = quat[2];	// z
    float sq_q1 = 2 * q1 * q1;
    float sq_q2 = 2 * q2 * q2;
    float sq_q3 = 2 * q3 * q3;
    float q1_q2 = 2 * q1 * q2;
    float q3_q0 = 2 * q3 * q0;
    float q1_q3 = 2 * q1 * q3;
    float q2_q0 = 2 * q2 * q0;
    float q2_q3 = 2 * q2 * q3;
    float q1_q0 = 2 * q1 * q0;

    R[0][0] = 1 - sq_q2 - sq_q3;
    R[0][1] = q1_q2 - q3_q0;
    R[0][2] = q1_q3 + q2_q0;
    R[1][0] = q1_q2 + q3_q0;
    R[1][1] = 1 - sq_q1 - sq_q3;
    R[1][2] = q2_q3 - q1_q0;
    R[2][0] = q1_q3 - q2_q0;
    R[2][1] = q2_q3 + q1_q0;
    R[2][2] = 1 - sq_q1 - sq_q2;

	euler[0] = atan2f(-R[1][0], R[0][0]) * RADTODEG;
	euler[1] = atan2f(-R[2][1], R[2][2]) * RADTODEG;
	euler[2] = asinf ( R[2][0])			* RADTODEG;
	if(euler[0] < 0)
	{
		euler[0] += 360;
	}
}


void qst_matrix_to_euler(float matrix[9], float euler[3])
{
	float R[3][3];

    R[0][0] = matrix[0];
    R[0][1] = matrix[1];
    R[0][2] = matrix[2];
    R[1][0] = matrix[3];
    R[1][1] = matrix[4];
    R[1][2] = matrix[5];
    R[2][0] = matrix[6];
    R[2][1] = matrix[7];
    R[2][2] = matrix[8];

	euler[0] = atan2f(-R[1][0], R[0][0]) * RADTODEG;
	euler[1] = atan2f(-R[2][1], R[2][2]) * RADTODEG;
	euler[2] = asinf ( R[2][0])			* RADTODEG;
	if(euler[0] < 0)
	{
		euler[0] += 360;
	}
}

void qst_matrix_to_quat(float matrix[9], float quat[4])
{
	float R[3][3];

    R[0][0] = matrix[0];
    R[0][1] = matrix[1];
    R[0][2] = matrix[2];
    R[1][0] = matrix[3];
    R[1][1] = matrix[4];
    R[1][2] = matrix[5];
    R[2][0] = matrix[6];
    R[2][1] = matrix[7];
    R[2][2] = matrix[8];

	const float Hx = R[0][0];
	const float My = R[1][1];
	const float Az = R[2][2];

	quat[0] = sqrtf(clamp(Hx - My - Az + 1) * 0.25f);
	quat[1] = sqrtf(clamp(-Hx + My - Az + 1) * 0.25f);
	quat[2] = sqrtf(clamp(-Hx - My + Az + 1) * 0.25f);
	quat[3] = sqrtf(clamp(Hx + My + Az + 1) * 0.25f);
	quat[0] = copysignf(quat[0], R[2][1] - R[1][2]);
	quat[1] = copysignf(quat[1], R[0][2] - R[2][0]);
	quat[2] = copysignf(quat[2], R[1][0] - R[0][1]);

	//float q_length =  sqrtf(quat[0] * quat[0] + quat[1] * quat[1] + quat[2] * quat[2] + quat[3] * quat[3]);
	//quat[0] = quat[0] / q_length;
	//quat[1] = quat[1] / q_length;
	//quat[2] = quat[2] / q_length;
	//quat[3] = quat[3] / q_length;
}


void qst_euler_to_matrix(float euler[3], float matrix[9])
{
	float yaw = euler[0]*DEGTORAD;
	float pitch = euler[0]*DEGTORAD;
	float roll = euler[0]*DEGTORAD;
	float cp = cosf(pitch);
	float sp = sinf(pitch); 	
	float sr = sinf(roll);
	float cr = cosf(roll);
	float sy = sinf(yaw);
	float cy = cosf(yaw);
	float R[3][3];

	R[0][0] = cy * cr;
	R[0][1] = (cy * sr * sp + cp * sy);
	R[0][2] = sy * sp - cy * cp * sr;

	R[1][0] = -(cr * sy);
	R[1][1] = -(sy * sr * sp -cy * cp);
	R[1][2] = cp*sr*sy + sp*cy;

	R[2][0] = sr;
	R[2][1] = -(cr * sp);
	R[2][2] = cr * cp;

   	matrix[0] =  R[0][0];
   	matrix[1] =  R[0][1];
   	matrix[2] =  R[0][2];
   	matrix[3] =  R[1][0];
   	matrix[4] =  R[1][1];
   	matrix[5] =  R[1][2];
   	matrix[6] =  R[2][0];
   	matrix[7] =  R[2][1];
   	matrix[8] =  R[2][2];
}


void qst_euler_to_quat(float euler[3], float quat[4])
{
	float yaw = euler[0]*DEGTORAD;
	float pitch = euler[0]*DEGTORAD;
	float roll = euler[0]*DEGTORAD;
	float cp = cosf(pitch);
	float sp = sinf(pitch); 	
	float sr = sinf(roll);
	float cr = cosf(roll);
	float sy = sinf(yaw);
	float cy = cosf(yaw);
	float R[3][3];

#if 0
	mat33_t_R_yzw[0][0] = cy * cr;
	mat33_t_R_yzw[0][1] = -(cy * sr * sp - cp * sy);
	mat33_t_R_yzw[0][2] = sy * sp + cy * cp * sy;

	mat33_t_R_yzw[1][0] = -(cr * sy);
	mat33_t_R_yzw[1][1] = cy * cp + sy * sr * sp;
	mat33_t_R_yzw[1][2] = -(cp * sy * sr - cy * sp);

	mat33_t_R_yzw[2][0] = -sr;
	mat33_t_R_yzw[2][1] = -(cr * sp);
	mat33_t_R_yzw[2][2] = cr * cp;
#endif
	R[0][0] = cy * cr;
	R[0][1] = (cy * sr * sp + cp * sy);
	R[0][2] = sy * sp - cy * cp * sr;

	R[1][0] = -(cr * sy);
	R[1][1] = -(sy * sr * sp -cy * cp);
	R[1][2] = cp*sr*sy + sp*cy;

	R[2][0] = sr;
	R[2][1] = -(cr * sp);
	R[2][2] = cr * cp;
	
	const float Hx = R[0][0];
	const float My = R[1][1];
	const float Az = R[2][2];

	quat[0] = sqrtf(clamp(Hx - My - Az + 1) * 0.25f);
	quat[1] = sqrtf(clamp(-Hx + My - Az + 1) * 0.25f);
	quat[2] = sqrtf(clamp(-Hx - My + Az + 1) * 0.25f);
	quat[3] = sqrtf(clamp(Hx + My + Az + 1) * 0.25f);
	quat[0] = copysignf(quat[0], R[2][1] - R[1][2]);
	quat[1] = copysignf(quat[1], R[0][2] - R[2][0]);
	quat[2] = copysignf(quat[2], R[1][0] - R[0][1]);

	//float q_length =  sqrtf(quat[0] * quat[0] + quat[1] * quat[1] + quat[2] * quat[2] + quat[3] * quat[3]);
	//quat[0] = quat[0] / q_length;
	//quat[1] = quat[1] / q_length;
	//quat[2] = quat[2] / q_length;
	//quat[3] = quat[3] / q_length;
}



