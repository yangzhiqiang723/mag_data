

#ifndef IMU_ALGO_AXIS6_H_
#define IMU_ALGO_AXIS6_H_

#ifdef __cplusplus
extern "C" {
#endif
//function declare
float constrain_float(float amt, float low, float high);
float wrap_PI(float angle_in_radians);
void qst_fusion_9axis_rotation_matrix(void);
void qst_fusion_nomag_rotation_matrix(void);
void qst_fusion_nogyro_rotation_matrix(void);
unsigned char qst_fusion_9axis_init(float accel_in[3], float mag_in[3]);
unsigned char qst_fusion_nomag_init(float accel_in[3], float mag_in[3]);

void qst_fusion_9axis_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart);
void qst_fusion_9axis_angle(float *rpy);
void qst_fusion_9axis_get_quaternion(float	quat[4]);

void qst_fusion_nomag_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart);
void qst_fusion_nomag_angle(float *rpy);
void qst_fusion_nomag_get_quaternion(float quat[4]);

void qst_fusion_nogyro_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart);
void qst_fusion_nogyro_angle(float *rpy);
void qst_fusion_nogyro_get_quaternion(float quat[4]);

void qst_fusion_gravity(float gra_data[3],int mode);
//void qst_fusion_get_quat(float quat[4],int mode);
//void qst_fusion_get_matrix(float matrix[9],int mode);

#ifdef __cplusplus
}
#endif

#endif /* IMU_ALGO_AXIS6_H_ */
