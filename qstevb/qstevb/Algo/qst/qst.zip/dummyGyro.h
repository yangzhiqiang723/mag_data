#ifndef DUMMYGYRO_H
#define DUMMYGYRO_H

#ifndef PI
#define PI					3.1415926535897932384626433832795f
#endif
#undef LOG_TAG
#define LOG_TAG "dummy-gyro"

#define MSCIF_NO_ERROR (0)
#define MSCIF_ERROR (-1)

#define GYROBUFC	4
#define GYROOUTBUF	10
#define GYRO_UNIT_SEC	1000000
#define TIMENUM 4
#define INIT_VALUE 1e6
#define W_Thres_X 5
#define W_Thres_Y 5
#define W_Thres_Z 5
#define W_Thres_Dyna_X 14
#define W_Thres_Dyna_Y 10
#define W_Thres_Dyna_Z 10

#ifndef PI_J
#define PI_J  3.14159265f
#endif

typedef long long				int64_t;


#define DegToRad                0.0174533
#define RadToDeg                57.29578

typedef struct
{
    int x_aix;
    int y_aix;
    int z_aix;
    int x_aix1;
    int y_aix1;
    int z_aix1;

    int last_x_A[GYROBUFC];
    int last_y_A[GYROBUFC];
    int last_z_A[GYROBUFC];
    int last_x_A1[GYROBUFC];
    int last_y_A1[GYROBUFC];
    int last_z_A1[GYROBUFC];

    long lastTime;
	
    int deltaTime[GYROBUFC];
    int gyro_yaw[GYROOUTBUF];
}VisualGyro;

typedef struct {
    float x[3];
} Ms3AxesData;

typedef struct
{
    Ms3AxesData sOriginalMsData;//magnetic raw data
    Ms3AxesData sOriginalGsData;//g-sensor raw data
    long systime;               //system time, uint: Micro second
    unsigned char magAlgoInside;       //0: inside magnetic algorithm; 1: outside algorithm and need input the yaw angle below
    int yawAngle;                //when "magAlgoInside" set to 1, we need to input this. Uint: degree.
    Ms3AxesData bollcent;       //Input the boll center position.
}ALGORITHM_IN;

typedef struct
{
    int pnDirection;            //yaw angle output, used for the compass.
    int pnIntensity;            //magnetic intensity used to check whether there is a disturb.
    unsigned char IsNormR;             //check whether we get a new stable calibration data, 1: get calibration data; other: something wrong.
    Ms3AxesData bollcent;       //Output the boll center position.
    VisualGyro gyro_out;         //visual gyro output, Uint: degree/second.
    Ms3AxesData calidRawData;
}ALGORITHM_OUT;

typedef struct _QMCSENSOR {
	float last_x;
	float last_y;
	float last_z;
	long  deltaTime;
	long  lastTime;
} QMCSENSOR;

typedef struct _QMCSENSORBUFF {
	QMCSENSOR buff[GYROBUFC];
} QMCSENSORBUFF;

typedef struct _QMCDGYRO {
	float pitch;
	float roll;
	float yaw;
} QMCDGYRO;

typedef struct _QMCDGYROBUFF {
	QMCDGYRO buff[GYROBUFC];
} QMCDGYROBUFF;

struct virtual_gyro{
	float yaw;
	float pitch;
	float roll;
	int64_t timeStamp;
};

struct virtual_gyro_matrix{
	float cs[3][3];
};

#ifdef __cplusplus
extern "C" {
#endif
void Qst_vgyro_matrix(float *Acc, float *Mag, struct virtual_gyro_matrix *matrix);
//void Qst_dummy_gyro(float *Acc, float *Mag, float *Vgyro, int64_t timeStamp);
void QST_fussion_PG(float *Acc, float *Mag, float *Vgyro, int64_t timeStamp);
#ifdef __cplusplus
}
#endif

#endif 
