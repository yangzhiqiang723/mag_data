#ifndef EULER_MATRIX_QUAT_H
#define EULER_MATRIX_QUAT_H

#ifdef __cplusplus
extern "C" {
#endif

extern void qst_quat_to_matrix(float quat[4], float matrix[9]);
extern void qst_quat_to_euler(float quat[4], float euler[3]);
extern void qst_matrix_to_euler(float matrix[9], float euler[3]);
extern void qst_matrix_to_quat(float matrix[9], float quat[4]);
extern void qst_euler_to_matrix(float euler[3], float matrix[9]);
extern void qst_euler_to_quat(float euler[3], float quat[4]);

#ifdef __cplusplus
}
#endif

#endif
