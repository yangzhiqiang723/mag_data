#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
//#include "imualgo_axis9.h"
//#include "ICAL_GDF30X.h"
#include "qstLog.h"

//#define IMUALGO_LOG


#define LPF_ALPHA           0.8f
#define MAX_CALI_COUNT      50
#define QST_FABS(v)         ((v<0)?(-1.0f*v):(v))
#define QST_ABS(v)          ((v<0)?(-1*v):(v))
#define Pi					3.14159265f
#define TODEG               57.2957796f
#define TORAD               Pi / 180.0f
#define GRAVITY_MSS         9.80665f


#define clamp(v) ((v) < 0 ? 0 : (v))

float fusion_9axis_q0 = 1.0f;
float fusion_9axis_q1 = 0.0f;
float fusion_9axis_q2 = 0.0f;
float fusion_9axis_q3 = 0.0f;


float fusion_9axis_kp = 4.0f;
float fusion_9axis_ki = 0.1f;


float fusion_9axis_mag_kp = 4.0f;

float fusion_9axis_Int_max = 0.05f;//0.15f;//
float fusion_9axis_exInt = 0;
float fusion_9axis_eyInt = 0;
float fusion_9axis_ezInt = 0;

float fusion_9axis_rot_mat[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};

float fusion_9axis_quaternion[4]= {1, 0, 0, 0};

//extern int AvgMagR;

/****************** 根据初始化欧拉角初始化四元数 *****************************/
unsigned char fusion_9axis_inited = 0;
float fusion_9axis_q_init[4] = {0, 0, 0, 0};
void qst_fusion_9axis_rad(float *rpy);

typedef struct
{
    float a1;
    float a2;
    float b0;
    float b1;
    float b2;
}QST_Filter_Parameter;

typedef struct
{
    float _delay_element_1;
    float _delay_element_2;
}QST_Filter_Buffer;

//1hz
//QST_Filter_Parameter gyro_filter_parameter = {-1.82269502,   0.837181747,   0.00362168206,    0.00724336412,   0.00362168206};
//2hz
//QST_Filter_Parameter gyro_filter_parameter = {-1.64745998,   0.7008968,   0.0133592002,    0.0267184004,   .0133592002};
//5hz
static QST_Filter_Parameter gyro_filter_parameter = {-1.14298046,   0.412801653,   0.0674552768,    0.134910554,   0.0674552768};    //10
//10hz
//QST_Filter_Parameter gyro_filter_parameter = {-0.369527251,   0.195815727,   0.206572115,    0.413144231,   0.206572115};    //10

//QST_Filter_Parameter gyro_filter_parameter = {-1.14298046,   0.412801653,   0.0674552768,   0.134910554,  0.0674552768};    //20
//QST_Filter_Parameter accel_filter_parameter = {-1.56101811,   0.641351581,   0.020083366,    0.0401667319,   0.020083366};    //10

//QST_Filter_Parameter gyro_filter_parameter = {-1.56101811,   0.641351581,   0.020083366,    0.0401667319,   0.020083366};        //10
//QST_Filter_Parameter accel_filter_parameter = {-1.77863193,   0.800802648,   0.00554271694,   0.0110854339,   0.00554271694};    //5

//QST_Filter_Parameter gyro_filter_parameter = {-1.77863193,   0.800802648,   0.00554271694,   0.0110854339,   0.00554271694};////5
//QST_Filter_Parameter accel_filter_parameter = {-1.91119695,   0.914975762,   0.000944691768,    0.00188938354,   0.000944691768};////2


//QST_Filter_Parameter gyro_filter_parameter = {-1.91119695,   0.914975762,   0.000944691768,    0.00188938354,   0.000944691768};////2
//QST_Filter_Parameter accel_filter_parameter = {-1.91119695,   0.914975762,   0.000944691768,    0.00188938354,   0.000944691768};////2

//QST_Filter_Parameter gyro_filter_parameter = {-1.95557833,   0.956543684,   0.000241359114,   0.000482718227,   0.000241359114};////1
//QST_Filter_Parameter accel_filter_parameter = {-1.95557833,   0.956543684,   0.000241359114,   0.000482718227,   0.000241359114};////1



QST_Filter_Buffer gyro_buffer[3] = {{0,0}};
QST_Filter_Buffer accel_buffer[3] = {{0,0}};

float gyro_max = 0.005f;

#define BUFFSER_SIZE 10
float accel_buffer_speed[BUFFSER_SIZE] = {0, 0};

//#define BUFFSER_SIZE 10
float gyro_buffer_speed[BUFFSER_SIZE] = {0, 0};

unsigned int static_delay = 0;
unsigned int static_flag = 0;
unsigned char static_interference_flag = 0;
unsigned char fusion_9axis_mode = 1;
unsigned char fusion_9axis_mode_last = 1;
unsigned int interference_delay = 0;

//#define QST_FUSION_9D_USE_MAG_RR

#if defined(QST_FUSION_9D_USE_MAG_RR)
void rr_sync_to_fusion(float *rr);
void ical_update_offset_flag_sync_to_fusion(int *flag);
#endif

/*!
 * \brief set second order butterworth filtering Parameters.
* \input float sample_freq:accel and gyro filter sampling frequency.
* \input float cutoff_freq:accel and gyro filter cut-off frequency.
* \output Butterworth_Filter *filter:filter coefficient.
* \return void 
 */
#if 0
static void set_cutoff_frequency(float sample_freq, float cutoff_freq, QST_Filter_Parameter *filter)
{    
    float fr = sample_freq / cutoff_freq;
    float ohm = tanf(Pi / fr);
    float c = 1.0f + 2.0f * cosf(Pi / 4.0f) * ohm + ohm * ohm;
    filter->b0 = ohm * ohm / c;
    filter->b1 = 2.0f * filter->b0;
    filter->b2 = filter->b0;
    filter->a1 = 2.0f * (ohm * ohm - 1.0f) / c;
    filter->a2 = (1.0f - 2.0f * cosf(Pi / 4.0f) * ohm + ohm * ohm) / c;
}
#endif

/*!
 * \brief set second order butterworth filtering Parameters.
* \input float sample:accel and gyro filter input value.
* \input Butterworth_Buffer *buffer:accel and gyro filter buffer value.
* \input float cutoff_freq:accel and gyro filter cut-off frequency.
* \return filter output value
 */
static float Filter_Apply(float sample, QST_Filter_Buffer *buffer, QST_Filter_Parameter *filter) 
{
    //do the filtering
    float delay_element_0 = sample - buffer->_delay_element_1 * filter->a1 - buffer->_delay_element_2 * filter->a2;

    const float output = delay_element_0 * filter->b0 + buffer->_delay_element_1 * filter->b1 + buffer->_delay_element_2 * filter->b2;

     buffer->_delay_element_2 = buffer->_delay_element_1;
   buffer->_delay_element_1 = delay_element_0;

    //return the value. Should be no need to check limits
    return output;
}


static float qst_min(float a, float b)
{
	return (a < b) ? a : b;
}


//constrain a value
float constrain_float(float amt, float low, float high) 
{
    return ((amt) < (low) ? (low) : ((amt) > (high) ? (high) : (amt)));
}

/*
  wrap an angle defined in radians to -PI ~ PI (equivalent to +- 180 degrees)
 */
#if 0
static float wrap_PI(float angle_in_radians)
{
    while (angle_in_radians > Pi) 
    {
        angle_in_radians -= 2.0f * Pi;
    }
    while (angle_in_radians < -Pi) 
    {
        angle_in_radians += 2.0f * Pi;
    }
    return angle_in_radians;
}
#endif


void qst_fusion_9axis_rotation_matrix(void)
{
    float q1q1 = fusion_9axis_q1 * fusion_9axis_q1;
    float q2q2 = fusion_9axis_q2 * fusion_9axis_q2;
    float q3q3 = fusion_9axis_q3 * fusion_9axis_q3;

    float q1q2 = fusion_9axis_q1 * fusion_9axis_q2;
    float q0q3 = fusion_9axis_q0 * fusion_9axis_q3;
    float q1q3 = fusion_9axis_q1 * fusion_9axis_q3;

    float q0q2 = fusion_9axis_q0 * fusion_9axis_q2;
    float q2q3 = fusion_9axis_q2 * fusion_9axis_q3;
    float q0q1 = fusion_9axis_q0 * fusion_9axis_q1;

    fusion_9axis_rot_mat[0][0] = 1 - 2 * (q2q2 + q3q3);
    fusion_9axis_rot_mat[0][1] = 2 * (q1q2 - q0q3);
    fusion_9axis_rot_mat[0][2] = 2 * (q1q3 + q0q2);
  
    fusion_9axis_rot_mat[1][0] = 2 * (q1q2 + q0q3);
    fusion_9axis_rot_mat[1][1] = 1 - 2 * (q1q1 + q3q3);
    fusion_9axis_rot_mat[1][2] = 2 * (q2q3 - q0q1);
  
    fusion_9axis_rot_mat[2][0] = 2 * (q1q3 - q0q2);
    fusion_9axis_rot_mat[2][1] = 2 * (q2q3 + q0q1);
    fusion_9axis_rot_mat[2][2] = 1 - 2 * (q1q1 + q2q2);
}


unsigned char qst_fusion_9axis_init(float accel_in[3], float mag_in[3]) 
{
    float accel_data[3] = {0, 0, 0};
    float mag_data[3] = {0, 0, 0};
    
    float mat33_t_R[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    accel_data[0] = accel_in[0];
    accel_data[1] = accel_in[1];
    accel_data[2] = accel_in[2];
    
    float normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);
    accel_data[0] = accel_data[0] / normalize;
    accel_data[1] = accel_data[1] / normalize;
    accel_data[2] = accel_data[2] / normalize;
    
    float pitch = -atan2f(accel_data[1], accel_data[2]);
    //fusion_9axis_init_pitch = pitch * TODEG;////俯仰角
    
    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);

    float roll = asinf((accel_data[0] / normalize));//横滚角
    //fusion_9axis_init_roll = roll * TODEG;//横滚角

    float cp = cosf(pitch);   //roll=0,  pitch=0;      //1
    float sp = sinf(pitch);   //0
    float sr = sinf(roll);    //0
    float cr = cosf(roll);    //  1

    mag_data[0] = mag_in[0];
    mag_data[1] = mag_in[1];
    mag_data[2] = mag_in[2];

    normalize = sqrtf(mag_data[0] * mag_data[0] + mag_data[1] * mag_data[1] + mag_data[2] * mag_data[2]);
    mag_data[0] = mag_data[0] / normalize;
    mag_data[1] = mag_data[1] / normalize;
    mag_data[2] = mag_data[2] / normalize;

    float hx = mag_data[0] * cr - mag_data[2] * sr;
    float hy = mag_data[0] * sp * sr + mag_data[1] * cp + mag_data[2] * cr * sp;
    float yaw = -atan2f(hx, hy);
    
//    fusion_9axis_init_yaw = yaw * TODEG;
//    if(fusion_9axis_init_yaw < 0.0f)
//    {
//        fusion_9axis_init_yaw += 360.0f;
//    }

//    D("%d; %d; %d\r\n", (int)fusion_9axis_init_pitch, (int)fusion_9axis_init_roll, (int)fusion_9axis_init_yaw);
    float sy = sinf(yaw);
    float cy = cosf(yaw);

    //    1 yaw       2 roll   3 pitch
    mat33_t_R[0][0] = cy * cr;
    mat33_t_R[0][1] = (cy * sr * sp + cp * sy);
    mat33_t_R[0][2] = sy * sp - cy * cp * sr;

    mat33_t_R[1][0] = -(cr * sy);
    mat33_t_R[1][1] = -(sy * sr * sp -cy * cp);
    mat33_t_R[1][2] =  cp * sr * sy + sp * cy;

    mat33_t_R[2][0] = sr;
    mat33_t_R[2][1] = -(cr * sp);
    mat33_t_R[2][2] = cr * cp;

    fusion_9axis_q_init[0] = sqrtf(clamp( mat33_t_R[0][0] - mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[1] = sqrtf(clamp(-mat33_t_R[0][0] + mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[2] = sqrtf(clamp(-mat33_t_R[0][0] - mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[3] = sqrtf(clamp( mat33_t_R[0][0] + mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);

    fusion_9axis_q_init[0] = copysignf(fusion_9axis_q_init[0], mat33_t_R[2][1] - mat33_t_R[1][2]);
    fusion_9axis_q_init[1] = copysignf(fusion_9axis_q_init[1], mat33_t_R[0][2] - mat33_t_R[2][0]);
    fusion_9axis_q_init[2] = copysignf(fusion_9axis_q_init[2], mat33_t_R[1][0] - mat33_t_R[0][1]);

    float q_length =  sqrtf(fusion_9axis_q_init[0] * fusion_9axis_q_init[0] + fusion_9axis_q_init[1] * fusion_9axis_q_init[1] + fusion_9axis_q_init[2] * fusion_9axis_q_init[2] + fusion_9axis_q_init[3] * fusion_9axis_q_init[3]);//归一化
    fusion_9axis_q_init[0] = fusion_9axis_q_init[0] / q_length;
    fusion_9axis_q_init[1] = fusion_9axis_q_init[1] / q_length;
    fusion_9axis_q_init[2] = fusion_9axis_q_init[2] / q_length;
    fusion_9axis_q_init[3] = fusion_9axis_q_init[3] / q_length;

    if(q_length > 0.95f && q_length < 1.05f)
    {
        fusion_9axis_inited = 1;
    } 
    else
    {
        fusion_9axis_inited = 0;
    }

    fusion_9axis_q0 = fusion_9axis_q_init[3];
    fusion_9axis_q1 = fusion_9axis_q_init[0];
    fusion_9axis_q2 = fusion_9axis_q_init[1];
    fusion_9axis_q3 = fusion_9axis_q_init[2];

    qst_fusion_9axis_rotation_matrix();

    return fusion_9axis_inited;
}


void qst_fusion_9axis_set_yaw(float angle_in[3])
{
    float mat33_t_R[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    float yaw = angle_in[0];
    float pitch = angle_in[1];
    float roll = angle_in[2];    //横滚角

    float cp = cosf(pitch);   //roll=0,  pitch=0;      //1
    float sp = sinf(pitch);                                 //0
    float sr = sinf(roll);                                     //0
    float cr = cosf(roll);                                   //  1
    float sy = sinf(yaw);
    float cy = cosf(yaw);

    //    1 yaw       2 roll   3 pitch
    mat33_t_R[0][0] = cy * cr;
    mat33_t_R[0][1] = (cy * sr * sp + cp * sy);
    mat33_t_R[0][2] = sy * sp - cy * cp * sr;

    mat33_t_R[1][0] = -(cr * sy);
    mat33_t_R[1][1] = -(sy * sr * sp -cy * cp);
    mat33_t_R[1][2] =  cp * sr * sy + sp * cy;

    mat33_t_R[2][0] = sr;
    mat33_t_R[2][1] = -(cr * sp);
    mat33_t_R[2][2] = cr * cp;

    ///*//和安卓坐标系一样
    fusion_9axis_q_init[0] = sqrtf(clamp( mat33_t_R[0][0] - mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[1] = sqrtf(clamp(-mat33_t_R[0][0] + mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[2] = sqrtf(clamp(-mat33_t_R[0][0] - mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[3] = sqrtf(clamp( mat33_t_R[0][0] + mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);


    fusion_9axis_q_init[0] = copysignf(fusion_9axis_q_init[0], mat33_t_R[2][1] - mat33_t_R[1][2]);
    fusion_9axis_q_init[1] = copysignf(fusion_9axis_q_init[1], mat33_t_R[0][2] - mat33_t_R[2][0]);
    fusion_9axis_q_init[2] = copysignf(fusion_9axis_q_init[2], mat33_t_R[1][0] - mat33_t_R[0][1]);

    float q_length =  sqrtf(fusion_9axis_q_init[0] * fusion_9axis_q_init[0] + fusion_9axis_q_init[1] * fusion_9axis_q_init[1] + fusion_9axis_q_init[2] * fusion_9axis_q_init[2] + fusion_9axis_q_init[3] * fusion_9axis_q_init[3]);//归一化
    fusion_9axis_q_init[0] = fusion_9axis_q_init[0] / q_length;
    fusion_9axis_q_init[1] = fusion_9axis_q_init[1] / q_length;
    fusion_9axis_q_init[2] = fusion_9axis_q_init[2] / q_length;
    fusion_9axis_q_init[3] = fusion_9axis_q_init[3] / q_length;

    fusion_9axis_q0 = fusion_9axis_q_init[3];
    fusion_9axis_q1 = fusion_9axis_q_init[0];
    fusion_9axis_q2 = fusion_9axis_q_init[1];
    fusion_9axis_q3 = fusion_9axis_q_init[2];
}




float rpy_out[3];
float rpy_out_lock[3];
int yaw_mag_timer;
float yaw_gyro_recovery = 0;

float mag_R_init = 0;


unsigned char imu_offset_static = 0;
unsigned short cali_count_static = 0;
float gyro_staticn_sum[3] = {0.0, 0.0, 0.0};
#define MAX_STATIC_COUNT 50
float gyro_static_offset[3];

unsigned char static_flag2 = 0;
unsigned short static_delay2 = 0;
#define GYRO_THRESH 2.0
float gyro_buffer2[BUFFSER_SIZE] = {0, 0};

float mag_buffer2[3] = {0, 0};

void qst_fusion_9axis_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart) {
    float ex_9axis = 0.0f;
    float ey_9axis = 0.0f;
    float ez_9axis = 0.0f;

    float integral_dt = *fusion_dt;
    float halfT = 0.5f * integral_dt;

    float accel_tmp[3] = {0.0f, 0.0f, 0.0f};
    float gyro_tmp[3] = {0.0f, 0.0f, 0.0f};
    float mag_tmp[3] = {0.0f, 0.0f, 0.0f};

    unsigned char axis = 0;

    if(integral_dt > 0.5f)
    {
        fusion_9axis_inited = 0;
    }
    else
    {
        if(integral_dt < 0.0f || integral_dt > 0.2f)
        {
            integral_dt = 0.02f;
            halfT = 0.5f * integral_dt;
        }
    }

    if(restart && *restart)
    {
        fusion_9axis_inited = 0;
    }

    for(axis = 0; axis < 3; axis++)
    {
        accel_tmp[axis] = fusion_accel[axis];
        //gyro_tmp[axis] = fusion_gyro[axis] + gyro_static_offset[axis]; 
        gyro_tmp[axis] = fusion_gyro[axis]; //add by lx 210928
        mag_tmp[axis] = fusion_mag[axis];
    }

    #ifdef ENBALE_DEBUG
    D("qst_log0: %f %f %f %f %f %f %f %f %f\n", accel_tmp[0], accel_tmp[1], accel_tmp[2], 
                    gyro_tmp[0], gyro_tmp[1], gyro_tmp[2], mag_tmp[0], mag_tmp[1], mag_tmp[2]);
    #endif

    if(!fusion_9axis_inited)
    {
        qst_fusion_9axis_init(accel_tmp, mag_tmp);
#if defined(QST_FUSION_9D_USE_MAG_RR)
        rr_sync_to_fusion(&mag_R_init);
#else
		mag_R_init = 0.0f;
#endif
        return;
    }

#if defined(QST_FUSION_9D_USE_MAG_RR)
    int update_offset_flag = 0;
    ical_update_offset_flag_sync_to_fusion(&update_offset_flag);
    
    if(update_offset_flag > 0)
    {
        fusion_9axis_mode = 1;
        if(update_offset_flag < 3)
        {
            rr_sync_to_fusion(&mag_R_init);
        }
    }
#endif
    float gz = fusion_9axis_rot_mat[2][0] * gyro_tmp[0] + fusion_9axis_rot_mat[2][1] * gyro_tmp[1] + fusion_9axis_rot_mat[2][2] * gyro_tmp[2];
    gz = Filter_Apply(gz, &gyro_buffer[2], &gyro_filter_parameter);
    float recip_norm = sqrtf(mag_tmp[0] * mag_tmp[0] + mag_tmp[1] * mag_tmp[1] + mag_tmp[2] * mag_tmp[2]);
    if((mag_R_init>1.0f)&&(recip_norm < (mag_R_init - 6) || recip_norm >  (mag_R_init + 6)))
    {
        /***********9切6判断:超过磁场半径范围**************************/
#if defined(QST_FUSION_9D_USE_MAG_RR)
        if(update_offset_flag < 1)
        {
            if(fusion_9axis_mode == 1)
            {
                fusion_9axis_mode = 0;
				#ifdef ENBALE_DEBUG
					D("qst_log6: 8888 \n");
				#endif
            }
        }
        yaw_gyro_recovery = 0;
#endif
        /***********9切6判断:超过磁场半径范围**************************/
    }else{
        /***********6切9恢复判断**************************/
        if(fabs(gz) > gyro_max * 5)//0.02)
        {
            yaw_gyro_recovery += -gz * integral_dt * TODEG;

            if(fabs(yaw_gyro_recovery) > 89)
            {
                if(fusion_9axis_mode == 0)
                {
                    fusion_9axis_mode = 1;
                }
            }
        }else{
            yaw_gyro_recovery = 0;
        }
        /*************6切9恢复************************/
    }

    for(axis = 0; axis < BUFFSER_SIZE - 1; axis++)
    {
        gyro_buffer2[axis] = gyro_buffer2[axis + 1];
    }
    gyro_buffer2[axis] = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);//gz;

#if defined(QST_FUSION_9D_USE_MAG_RR)
    if(update_offset_flag < 1)
#endif
    {
        if(fabs(gyro_buffer2[0]) < GYRO_THRESH && fabs(gyro_buffer2[1]) < GYRO_THRESH && fabs(gyro_buffer2[2]) < GYRO_THRESH && fabs(gyro_buffer2[3]) < GYRO_THRESH && fabs(gyro_buffer2[4]) < GYRO_THRESH
            && fabs(gyro_buffer2[5]) < GYRO_THRESH && fabs(gyro_buffer2[6]) < GYRO_THRESH && fabs(gyro_buffer2[7]) < GYRO_THRESH && fabs(gyro_buffer2[8]) < GYRO_THRESH && fabs(gyro_buffer2[9]) < GYRO_THRESH)
        {
            //float mag_normal = sqrtf((mag_tmp[0] - mag_buffer2[0]) * (mag_tmp[0] - mag_buffer2[0]) + (mag_tmp[1] - mag_buffer2[1]) * (mag_tmp[1] - mag_buffer2[1]) + (mag_tmp[2] - mag_buffer2[2]) * (mag_tmp[2] - mag_buffer2[2]));
            float mag_normal = fabs(mag_tmp[0] - mag_buffer2[0]) + fabs(mag_tmp[1] - mag_buffer2[1]) + fabs(mag_tmp[2] - mag_buffer2[2]);
            if(mag_normal > 5)
            {
                if(fusion_9axis_mode == 1)
                {
                    fusion_9axis_mode = 0;
					#ifdef ENBALE_DEBUG
						D("qst_log7: 9999 \n");
					#endif
                    //D("ma_q2 8888 \n");
                }
            }
        }
    }

    mag_buffer2[0] = mag_tmp[0];
    mag_buffer2[1] = mag_tmp[1];
    mag_buffer2[2] = mag_tmp[2];

    if(fusion_9axis_mode == 0)
    {
        if(fusion_9axis_mode_last == 1)
        {
            fusion_9axis_exInt = 0.0f;
            fusion_9axis_eyInt = 0.0f;
            fusion_9axis_ezInt = 0.0f;
        }
    }

    fusion_9axis_mode_last = fusion_9axis_mode;

    //fusion_9axis_mode = 0;

    //D("maxianhu_status2 %d  %d %f %f\n", fusion_9axis_mode, update_offset_flag, mag_R_init, recip_norm);
	float spinRate = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);
    if(fusion_9axis_mode)
    {
        // Normalise magnetometer measurement
        mag_tmp[0] = mag_tmp[0] / recip_norm;
        mag_tmp[1] = mag_tmp[1] / recip_norm;
        mag_tmp[2] = mag_tmp[2] / recip_norm;

        // Magnetometer correction
        // Project mag field vector to global frame and extract XY component
        float hx = fusion_9axis_rot_mat[0][0] * mag_tmp[0] + fusion_9axis_rot_mat[0][1] * mag_tmp[1] + fusion_9axis_rot_mat[0][2] * mag_tmp[2];
        float hy = fusion_9axis_rot_mat[1][0] * mag_tmp[0] + fusion_9axis_rot_mat[1][1] * mag_tmp[1] + fusion_9axis_rot_mat[1][2] * mag_tmp[2];
        float hz = fusion_9axis_rot_mat[2][0] * mag_tmp[0] + fusion_9axis_rot_mat[2][1] * mag_tmp[1] + fusion_9axis_rot_mat[2][2] * mag_tmp[2];

        float by = sqrtf(hx * hx + hy * hy);
        float bz = hz;

        //n系中的地磁向量[bx,by,bz]转换到b系中，得到[wx,wy,wz]
        float wx = fusion_9axis_rot_mat[1][0] * by + fusion_9axis_rot_mat[2][0] * bz;
        float wy = fusion_9axis_rot_mat[1][1] * by + fusion_9axis_rot_mat[2][1] * bz;
        float wz = fusion_9axis_rot_mat[1][2] * by + fusion_9axis_rot_mat[2][2] * bz;

		float fifty_dps =  0.873f;//50dps
		float gainMult = 1.0f;
		if(spinRate > fifty_dps)
		{
			gainMult = qst_min(spinRate / fifty_dps, 2.50f);
		}
		ex_9axis = (mag_tmp[1] * wz - mag_tmp[2] * wy) * fusion_9axis_mag_kp * gainMult;
		ey_9axis = (mag_tmp[2] * wx - mag_tmp[0] * wz) * fusion_9axis_mag_kp * gainMult;
		ez_9axis = (mag_tmp[0] * wy - mag_tmp[1] * wx) * fusion_9axis_mag_kp * gainMult;
    }

    recip_norm = sqrtf(accel_tmp[0] * accel_tmp[0] + accel_tmp[1] * accel_tmp[1] + accel_tmp[2] * accel_tmp[2]);
	if(recip_norm > GRAVITY_MSS * 0.9f && recip_norm <  GRAVITY_MSS * 1.1f)
	{
        accel_tmp[0] = accel_tmp[0] / recip_norm;
        accel_tmp[1] = accel_tmp[1] / recip_norm;
        accel_tmp[2] = accel_tmp[2] / recip_norm;

        ex_9axis += (accel_tmp[1] * fusion_9axis_rot_mat[2][2] - accel_tmp[2] * fusion_9axis_rot_mat[2][1]) * fusion_9axis_kp;
        ey_9axis += (accel_tmp[2] * fusion_9axis_rot_mat[2][0] - accel_tmp[0] * fusion_9axis_rot_mat[2][2]) * fusion_9axis_kp;
        ez_9axis += (accel_tmp[0] * fusion_9axis_rot_mat[2][1] - accel_tmp[1] * fusion_9axis_rot_mat[2][0]) * fusion_9axis_kp;
    }

    //D("maxianhu_status,%d %d  dt:%f %f %f %f\n", *mag_status, fusion_9axis_mode, integral_dt, gyro_tmp[0], gyro_tmp[1], gyro_tmp[2]);

    if(gyro_tmp[0] > -gyro_max && gyro_tmp[0] <  gyro_max)
    {
        gyro_tmp[0] = 0;
    }
    if(gyro_tmp[1] > -gyro_max && gyro_tmp[1] <  gyro_max)
    {
        gyro_tmp[1] = 0;
    }
    if(gyro_tmp[2] > -gyro_max && gyro_tmp[2] <  gyro_max)
    {
        gyro_tmp[2] = 0;
    }

	spinRate = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);
	if(spinRate < 0.175f)///0.873f)//0.175f)//0.34f)//1.075f)
	{
		fusion_9axis_exInt += ex_9axis * fusion_9axis_ki * integral_dt;
		fusion_9axis_eyInt += ey_9axis * fusion_9axis_ki * integral_dt;
		fusion_9axis_ezInt += ez_9axis * fusion_9axis_ki * integral_dt;

		fusion_9axis_exInt = constrain_float(fusion_9axis_exInt, -fusion_9axis_Int_max, fusion_9axis_Int_max);
		fusion_9axis_eyInt = constrain_float(fusion_9axis_eyInt, -fusion_9axis_Int_max, fusion_9axis_Int_max);
		fusion_9axis_ezInt = constrain_float(fusion_9axis_ezInt, -fusion_9axis_Int_max, fusion_9axis_Int_max);
	}
	else
	{
		fusion_9axis_exInt = 0.0f;
		fusion_9axis_eyInt = 0.0f;
		fusion_9axis_ezInt = 0.0f;
	}

    #ifdef ENBALE_DEBUG
    D("qst_log1: %f %f %f\n", fusion_9axis_exInt, fusion_9axis_eyInt, fusion_9axis_ezInt);
    #endif

    gyro_tmp[0] = gyro_tmp[0] + ex_9axis + fusion_9axis_exInt;
    gyro_tmp[1] = gyro_tmp[1] + ey_9axis + fusion_9axis_eyInt;
    gyro_tmp[2] = gyro_tmp[2] + ez_9axis + fusion_9axis_ezInt;

    float qw = fusion_9axis_q0;
    float qx = fusion_9axis_q1;
    float qy = fusion_9axis_q2;
    float qz = fusion_9axis_q3;

    fusion_9axis_q0 += (-qx * gyro_tmp[0] - qy * gyro_tmp[1] - qz * gyro_tmp[2]) * halfT;
    fusion_9axis_q1 += (+qw * gyro_tmp[0] + qy * gyro_tmp[2] - qz * gyro_tmp[1]) * halfT;
    fusion_9axis_q2 += (+qw * gyro_tmp[1] - qx * gyro_tmp[2] + qz * gyro_tmp[0]) * halfT;
    fusion_9axis_q3 += (+qw * gyro_tmp[2] + qx * gyro_tmp[1] - qy * gyro_tmp[0]) * halfT;

    recip_norm = sqrtf(fusion_9axis_q0 * fusion_9axis_q0 + fusion_9axis_q1 * fusion_9axis_q1 + fusion_9axis_q2 * fusion_9axis_q2 + fusion_9axis_q3 * fusion_9axis_q3);
    fusion_9axis_q0 = fusion_9axis_q0 / recip_norm;
    fusion_9axis_q1 = fusion_9axis_q1 / recip_norm;
    fusion_9axis_q2 = fusion_9axis_q2 / recip_norm;
    fusion_9axis_q3 = fusion_9axis_q3 / recip_norm;

    recip_norm = sqrtf(fusion_accel[0] * fusion_accel[0] + fusion_accel[1] * fusion_accel[1] + fusion_accel[2] * fusion_accel[2]);
    float gyro_recip_norm = sqrtf(fusion_gyro[0] * fusion_gyro[0] + fusion_gyro[1] * fusion_gyro[1] + fusion_gyro[2] * fusion_gyro[2]);

    float accel_sum = 0;
    float gyro_sum = 0;
    for(axis = 0; axis < BUFFSER_SIZE - 1; axis++)
    {
        accel_buffer_speed[axis] = accel_buffer_speed[axis + 1];
        accel_sum = accel_sum + accel_buffer_speed[axis];

        gyro_buffer_speed[axis] = gyro_buffer_speed[axis + 1];
        gyro_sum = gyro_sum + gyro_buffer_speed[axis];
    }
    accel_buffer_speed[axis] = recip_norm;
    accel_sum = accel_sum + accel_buffer_speed[axis];
    float accel_average = accel_sum / BUFFSER_SIZE;

    gyro_buffer_speed[axis] = gyro_recip_norm;
    gyro_sum = gyro_sum + gyro_buffer_speed[axis];
    float gyro_average = gyro_sum / BUFFSER_SIZE;

    accel_sum = 0;
    gyro_sum = 0;
    for(axis = 0; axis < BUFFSER_SIZE; axis++)
    {
        accel_sum = accel_sum + (accel_buffer_speed[axis] - accel_average) * (accel_buffer_speed[axis] - accel_average);
        gyro_sum = gyro_sum + (gyro_buffer_speed[axis] - gyro_average) * (gyro_buffer_speed[axis] - gyro_average);
    }
    float accel_standard_deviation = sqrtf(accel_sum / BUFFSER_SIZE);
    float gyro_standard_deviation = sqrtf(gyro_sum / BUFFSER_SIZE);

    //D("%f %f\n", gyro_norm, accel_standard_deviation);
    if(spinRate > gyro_max * 4)    //
    {
        static_flag = 0;
        static_delay = 0;
    }
    //D("maxianhu_status %d %f %f %f %f\n", static_flag, accel_standard_deviation, gyro_static_offset[0], gyro_static_offset[1], gyro_static_offset[2]);
	if(accel_standard_deviation < 0.6f)//\u0178???u0152¨¬??
    {
		if(gyro_standard_deviation < 0.02f)
		{
			if(static_flag == 0)
			{
				if(static_delay < 80)
				{
					static_delay++;
					if(static_delay == 60)
					{
						if(fusion_9axis_mode)
						{
							qst_fusion_9axis_init(accel_tmp, mag_tmp);
						}
					}
				}else{
					static_delay = 0;
					static_flag = 1;
					rpy_out_lock[0] = rpy_out[0];
				}
			}else{
				rpy_out_lock[1] = rpy_out[1];
				rpy_out_lock[2] = rpy_out[2];

                #ifdef ENBALE_DEBUG
				D("xiaomi7 %d %f %f %f %f %f %f\n", fusion_9axis_mode, rpy_out_lock[0],
						 rpy_out_lock[1], rpy_out_lock[2], fusion_gyro[0], fusion_gyro[1],
						 fusion_gyro[2]);
                #endif
                //if(fusion_9axis_mode == 0)
                qst_fusion_9axis_set_yaw(rpy_out_lock);
                #ifdef ENBALE_DEBUG
                D("qst_log4: %f %f %f\n", rpy_out_lock[0], rpy_out_lock[1],rpy_out_lock[2]);
                #endif
            }
		}
	}else{
		static_delay = 0;
		static_flag = 0;
	}

    qst_fusion_9axis_rotation_matrix();

    qst_fusion_9axis_rad(rpy_out);

    #ifdef ENBALE_DEBUG
    D("qst_log2: %d %f %f %f %f\n", fusion_9axis_mode,integral_dt,  rpy_out[0] * TODEG, rpy_out[1] * TODEG, rpy_out[2] * TODEG);
    D("qst_log3: %d %d %f %f %f %f %f\n", static_flag, static_flag2, accel_standard_deviation, gyro_standard_deviation, gyro_static_offset[0], gyro_static_offset[1], gyro_static_offset[2]);
    #endif
}

//static float ical_pitch = 0;
//static float ical_roll = 0;
void qst_fusion_9axis_rad(float *rpy)
{
    float roll  = asinf(fusion_9axis_rot_mat[2][0]);
    float pitch = atan2f(-fusion_9axis_rot_mat[2][1], fusion_9axis_rot_mat[2][2]);
    float yaw = atan2f(-fusion_9axis_rot_mat[1][0], fusion_9axis_rot_mat[0][0]);

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}


void qst_fusion_9axis_angle(float *rpy)
{
    float roll  = asinf(fusion_9axis_rot_mat[2][0]) * TODEG;
    float pitch = -atan2f(fusion_9axis_rot_mat[2][1], fusion_9axis_rot_mat[2][2]) * TODEG;
    float yaw = -atan2f(fusion_9axis_rot_mat[1][0], fusion_9axis_rot_mat[0][0]) * TODEG;

    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}

void qst_fusion_9axis_get_quaternion(float quat[4])
{
    quat[0] = sqrtf(clamp( fusion_9axis_rot_mat[0][0] - fusion_9axis_rot_mat[1][1] - fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[1] = sqrtf(clamp(-fusion_9axis_rot_mat[0][0] + fusion_9axis_rot_mat[1][1] - fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[2] = sqrtf(clamp(-fusion_9axis_rot_mat[0][0] - fusion_9axis_rot_mat[1][1] + fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[3] = sqrtf(clamp( fusion_9axis_rot_mat[0][0] + fusion_9axis_rot_mat[1][1] + fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[0] = copysignf(quat[0], fusion_9axis_rot_mat[2][1] - fusion_9axis_rot_mat[1][2]);
    quat[1] = copysignf(quat[1], fusion_9axis_rot_mat[0][2] - fusion_9axis_rot_mat[2][0]);
    quat[2] = copysignf(quat[2], fusion_9axis_rot_mat[1][0] - fusion_9axis_rot_mat[0][1]);
}



float fusion_nomag_q0 = 1.0f;
float fusion_nomag_q1 = 0.0f;
float fusion_nomag_q2 = 0.0f;
float fusion_nomag_q3 = 0.0f;

float fusion_nomag_kp = 6.0f;
float fusion_nomag_ki = 0.1f;
float fusion_nomag_Int_max = 0.05f;
float fusion_nomag_exInt = 0;
float fusion_nomag_eyInt = 0;
float fusion_nomag_ezInt = 0;

float fusion_nomag_rot_mat[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};

float fusion_nomag_quaternion[4] = {1, 0, 0, 0};

unsigned char fusion_nomag_inited = 0;
float fusion_nomag_q_init[4] = {0, 0, 0, 0};

void qst_fusion_nomag_rotation_matrix(void)
{
    float q2q2 = fusion_nomag_q2 * fusion_nomag_q2;
    float q2q3 = fusion_nomag_q2 * fusion_nomag_q3;
    float q1q1 = fusion_nomag_q1 * fusion_nomag_q1;
    float q1q2 = fusion_nomag_q1 * fusion_nomag_q2;
    float q1q3 = fusion_nomag_q1 * fusion_nomag_q3;
    float q0q1 = fusion_nomag_q0 * fusion_nomag_q1;
    float q0q2 = fusion_nomag_q0 * fusion_nomag_q2;
    float q0q3 = fusion_nomag_q0 * fusion_nomag_q3;
    float q3q3 = fusion_nomag_q3 * fusion_nomag_q3;

    fusion_nomag_rot_mat[0][0] = 1 - 2 * (q2q2 + q3q3);
    fusion_nomag_rot_mat[0][1] = 2 * (q1q2 - q0q3);
    fusion_nomag_rot_mat[0][2] = 2 * (q1q3 + q0q2);

    fusion_nomag_rot_mat[1][0] = 2 * (q1q2 + q0q3);
    fusion_nomag_rot_mat[1][1] = 1 - 2 * (q1q1 + q3q3);
    fusion_nomag_rot_mat[1][2] = 2 * (q2q3 - q0q1);

    fusion_nomag_rot_mat[2][0] = 2 * (q1q3 - q0q2);
    fusion_nomag_rot_mat[2][1] = 2 * (q2q3 + q0q1);
    fusion_nomag_rot_mat[2][2] = 1-2 * (q1q1 + q2q2);
}

//float fusion_nomag_init_pitch = 0;
//float fusion_nomag_init_roll = 0;
//float fusion_nomag_init_yaw = 0;
unsigned char qst_fusion_nomag_init(float accel_in[3], float mag_in[3])
{
    float accel_data[3] = {0, 0, 0};
    float mat33_t_R[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    accel_data[0] = accel_in[0];
    accel_data[1] = accel_in[1];
    accel_data[2] = accel_in[2];

    float    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);
    accel_data[0] = accel_data[0] / normalize;
    accel_data[1] = accel_data[1] / normalize;
    accel_data[2] = accel_data[2] / normalize;

    float pitch = -atan2f(accel_data[1], accel_data[2]);
    //fusion_nomag_init_pitch = pitch * TODEG;////俯仰角

    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);

    float roll = asinf((accel_data[0] / normalize));//横滚角
    //fusion_nomag_init_roll = roll * TODEG;//横滚角

    float cp = cosf(pitch);   //roll=0,  pitch=0;      //1
    float sp = sinf(pitch);   //0
    float sr = sinf(roll);    //0
    float cr = cosf(roll);    //  1

    float yaw = 0;

//    fusion_nomag_init_yaw = yaw * TODEG;
//    if(fusion_nomag_init_yaw < 0.0f)
//    {
//        fusion_nomag_init_yaw += 360.0f;
//    }
//
    //D("inited:%d; %d; %d\r\n", (int)fusion_nomag_init_pitch, (int)fusion_nomag_init_roll, (int)fusion_nomag_init_yaw);

    float sy = sinf(yaw);
    float cy = cosf(yaw);

    // 1 yaw       2 roll   3 pitch
    mat33_t_R[0][0] = cy * cr;
    mat33_t_R[0][1] = -(cy * sr * sp - cp * sy);
    mat33_t_R[0][2] = sy * sp + cy * cp * sy;

    mat33_t_R[1][0] = -(cr * sy);
    mat33_t_R[1][1] = cy * cp + sy * sr * sp;
    mat33_t_R[1][2] = -(cp * sy * sr - cy * sp);

    mat33_t_R[2][0] = -sr;
    mat33_t_R[2][1] = -(cr * sp);
    mat33_t_R[2][2] = cr * cp;

    fusion_nomag_q_init[0] = sqrtf(clamp( mat33_t_R[0][0] - mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nomag_q_init[1] = sqrtf(clamp(-mat33_t_R[0][0] + mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nomag_q_init[2] = sqrtf(clamp(-mat33_t_R[0][0] - mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nomag_q_init[3] = sqrtf(clamp( mat33_t_R[0][0] + mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);

    fusion_nomag_q_init[0] = copysignf(fusion_nomag_q_init[0], mat33_t_R[2][1] - mat33_t_R[1][2]);
    fusion_nomag_q_init[1] = copysignf(fusion_nomag_q_init[1], mat33_t_R[0][2] - mat33_t_R[2][0]);
    fusion_nomag_q_init[2] = copysignf(fusion_nomag_q_init[2], mat33_t_R[1][0] - mat33_t_R[0][1]);

    float q_length =  sqrtf(fusion_nomag_q_init[0] * fusion_nomag_q_init[0] + fusion_nomag_q_init[1] * fusion_nomag_q_init[1] + fusion_nomag_q_init[2] * fusion_nomag_q_init[2] + fusion_nomag_q_init[3] * fusion_nomag_q_init[3]);//归一化
    fusion_nomag_q_init[0] = fusion_nomag_q_init[0] / q_length;
    fusion_nomag_q_init[1] = fusion_nomag_q_init[1] / q_length;
    fusion_nomag_q_init[2] = fusion_nomag_q_init[2] / q_length;
    fusion_nomag_q_init[3] = fusion_nomag_q_init[3] / q_length;

    if(/*isfinite(fusion_nomag_q_init[0]) && isfinite(fusion_nomag_q_init[1]) &&
        isfinite(fusion_nomag_q_init[2]) && isfinite(fusion_nomag_q_init[3]) &&*/
        q_length > 0.95f && q_length < 1.05f)
    {
        fusion_nomag_inited = 1;
    } 
    else
    {
        fusion_nomag_inited = 0;
    }

    fusion_nomag_q0 = fusion_nomag_q_init[3];
    fusion_nomag_q1 = fusion_nomag_q_init[0];
    fusion_nomag_q2 = fusion_nomag_q_init[1];
    fusion_nomag_q3 = fusion_nomag_q_init[2];

    qst_fusion_nomag_rotation_matrix();

    return fusion_nomag_inited;
}





void qst_fusion_nomag_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart)
{
    float ex = 0.0f;
    float ey = 0.0f;
    float ez = 0.0f;
    
    float integral_dt = *fusion_dt;
    float halfT = 0.5f * integral_dt;

    float accel_tmp[3] = {0.0f, 0.0f, 0.0f};
    float gyro_tmp[3] = {0.0f, 0.0f, 0.0f};
    float mag_tmp[3] = {0.0f, 0.0f, 0.0f};

    
    
    accel_tmp[0] = fusion_accel[0];
    accel_tmp[1] = fusion_accel[1];
    accel_tmp[2] = fusion_accel[2];
    
    gyro_tmp[0] = fusion_gyro[0];
    gyro_tmp[1] = fusion_gyro[1];
    gyro_tmp[2] = fusion_gyro[2];


//    if(restart&&*restart) 
//    {
//        fusion_nomag_inited = 0;
//    }
    

    if(integral_dt > 0.5f)
    {
        fusion_nomag_inited = 0;
    }
    else
    {
        if(integral_dt < 0.0f || integral_dt > 0.04f)
        {
            integral_dt = 0.005f;
            halfT = 0.5f * integral_dt;
        }
    }

    if(restart&&*restart)
    {
        fusion_nomag_inited = 0;
    }

    if(!fusion_nomag_inited)
    {
        qst_fusion_nomag_init(accel_tmp, mag_tmp);
        return ;
    }

    float recip_norm = sqrtf(accel_tmp[0] * accel_tmp[0] + accel_tmp[1] * accel_tmp[1] + accel_tmp[2] * accel_tmp[2]);
    if(recip_norm > GRAVITY_MSS * 0.9f && recip_norm <  GRAVITY_MSS * 1.1f)
    {
        accel_tmp[0] = accel_tmp[0] / recip_norm;
        accel_tmp[1] = accel_tmp[1] / recip_norm;
        accel_tmp[2] = accel_tmp[2] / recip_norm;

        ex = (accel_tmp[1] * fusion_nomag_rot_mat[2][2] - accel_tmp[2] * fusion_nomag_rot_mat[2][1]) * fusion_nomag_kp;
        ey = (accel_tmp[2] * fusion_nomag_rot_mat[2][0] - accel_tmp[0] * fusion_nomag_rot_mat[2][2]) * fusion_nomag_kp;
        ez = (accel_tmp[0] * fusion_nomag_rot_mat[2][1] - accel_tmp[1] * fusion_nomag_rot_mat[2][0]) * fusion_nomag_kp;
    }


    float spinRate = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);
    if(spinRate < 0.35f) //20
    {
        fusion_nomag_exInt += ex * fusion_nomag_ki * integral_dt;
        fusion_nomag_eyInt += ey * fusion_nomag_ki * integral_dt;
        fusion_nomag_ezInt += ez * fusion_nomag_ki * integral_dt;
        fusion_nomag_exInt = constrain_float(fusion_nomag_exInt, -fusion_nomag_Int_max, fusion_nomag_Int_max);
        fusion_nomag_eyInt = constrain_float(fusion_nomag_eyInt, -fusion_nomag_Int_max, fusion_nomag_Int_max);
        fusion_nomag_ezInt = constrain_float(fusion_nomag_ezInt, -fusion_nomag_Int_max, fusion_nomag_Int_max);
    }
    else
    {
        fusion_nomag_exInt = 0.0f;
        fusion_nomag_eyInt = 0.0f;
        fusion_nomag_ezInt = 0.0f;
    }

    gyro_tmp[0] = gyro_tmp[0] + ex + fusion_nomag_exInt;
    gyro_tmp[1] = gyro_tmp[1] + ey + fusion_nomag_eyInt;
    gyro_tmp[2] = gyro_tmp[2] + ez + fusion_nomag_ezInt;

    float qw = fusion_nomag_q0;
    float qx = fusion_nomag_q1;
    float qy = fusion_nomag_q2;
    float qz = fusion_nomag_q3;

    fusion_nomag_q0 += (-qx * gyro_tmp[0] - qy * gyro_tmp[1] - qz * gyro_tmp[2]) * halfT;
    fusion_nomag_q1 += (+qw * gyro_tmp[0] + qy * gyro_tmp[2] - qz * gyro_tmp[1]) * halfT;
    fusion_nomag_q2 += (+qw * gyro_tmp[1] - qx * gyro_tmp[2] + qz * gyro_tmp[0]) * halfT;
    fusion_nomag_q3 += (+qw * gyro_tmp[2] + qx * gyro_tmp[1] - qy * gyro_tmp[0]) * halfT;

    recip_norm = sqrtf(fusion_nomag_q0 * fusion_nomag_q0 + fusion_nomag_q1 * fusion_nomag_q1 + fusion_nomag_q2 * fusion_nomag_q2 + fusion_nomag_q3 * fusion_nomag_q3);
    fusion_nomag_q0 = fusion_nomag_q0 / recip_norm;
    fusion_nomag_q1 = fusion_nomag_q1 / recip_norm;
    fusion_nomag_q2 = fusion_nomag_q2 / recip_norm;
    fusion_nomag_q3 = fusion_nomag_q3 / recip_norm;

    qst_fusion_nomag_rotation_matrix();
}


void qst_fusion_nomag_angle(float *rpy)
{
    float roll  = asinf(fusion_nomag_rot_mat[2][0]) * TODEG;
    float pitch = -atan2f(fusion_nomag_rot_mat[2][1], fusion_nomag_rot_mat[2][2]) * TODEG;
    float yaw = -atan2f(fusion_nomag_rot_mat[1][0], fusion_nomag_rot_mat[0][0]) * TODEG;

    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}


void qst_fusion_nomag_get_quaternion(float quat[4])
{
    const float Hx = fusion_nomag_rot_mat[0][0];
    const float My = fusion_nomag_rot_mat[1][1];
    const float Az = fusion_nomag_rot_mat[2][2];
    quat[0] = sqrtf( clamp( Hx - My - Az + 1) * 0.25f );
    quat[1] = sqrtf( clamp(-Hx + My - Az + 1) * 0.25f );
    quat[2] = sqrtf( clamp(-Hx - My + Az + 1) * 0.25f );
    quat[3] = sqrtf( clamp( Hx + My + Az + 1) * 0.25f );
    quat[0] = copysignf(quat[0], fusion_nomag_rot_mat[2][1] - fusion_nomag_rot_mat[1][2]);
    quat[1] = copysignf(quat[1], fusion_nomag_rot_mat[0][2] - fusion_nomag_rot_mat[2][0]);
    quat[2] = copysignf(quat[2], fusion_nomag_rot_mat[1][0] - fusion_nomag_rot_mat[0][1]);
}


float fusion_nogyro_q0 = 1.0f;
float fusion_nogyro_q1 = 0.0f;
float fusion_nogyro_q2 = 0.0f;
float fusion_nogyro_q3 = 0.0f;

float fusion_nogyro_mag_kp = 2.0f;

float fusion_nogyro_kp = 2.0f;
float fusion_nogyro_ki = 0.1f;
float fusion_nogyro_Int_max = 0.05f;
float fusion_nogyro_exInt = 0;
float fusion_nogyro_eyInt = 0;
float fusion_nogyro_ezInt = 0;

float fusion_nogyro_rot_mat[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};

float fusion_nogyro_quaternion[4]= {1, 0, 0, 0};

/****************** 根据初始化欧拉角初始化四元数 *****************************/
unsigned char fusion_nogyro_inited = 0;
float fusion_nogyro_q_init[4] = {0, 0, 0, 0};


void qst_fusion_nogyro_rotation_matrix(void)
{
    float q2q2 = fusion_nogyro_q2 * fusion_nogyro_q2;
    float q2q3 = fusion_nogyro_q2 * fusion_nogyro_q3;
    float q1q1 = fusion_nogyro_q1 * fusion_nogyro_q1;
    float q1q2 = fusion_nogyro_q1 * fusion_nogyro_q2;
    float q1q3 = fusion_nogyro_q1 * fusion_nogyro_q3;
    float q0q1 = fusion_nogyro_q0 * fusion_nogyro_q1;
    float q0q2 = fusion_nogyro_q0 * fusion_nogyro_q2;
    float q0q3 = fusion_nogyro_q0 * fusion_nogyro_q3;
    float q3q3 = fusion_nogyro_q3 * fusion_nogyro_q3;

    fusion_nogyro_rot_mat[0][0] = 1 - 2 * (q2q2 + q3q3);
    fusion_nogyro_rot_mat[0][1] = 2 * (q1q2 - q0q3);
    fusion_nogyro_rot_mat[0][2] = 2 * (q1q3 + q0q2);

    fusion_nogyro_rot_mat[1][0] = 2 * (q1q2 + q0q3);
    fusion_nogyro_rot_mat[1][1] = 1 - 2 * (q1q1 + q3q3);
    fusion_nogyro_rot_mat[1][2] = 2 * (q2q3 - q0q1);

    fusion_nogyro_rot_mat[2][0] = 2 * (q1q3 - q0q2);
    fusion_nogyro_rot_mat[2][1] = 2 * (q2q3 + q0q1);
    fusion_nogyro_rot_mat[2][2] = 1-2 * (q1q1 + q2q2);
}





void qst_fusion_nogyro_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart)
{
    float accel_data[3] = {0.0f, 0.0f, 0.0f};
    float mag_data[3] = {0.0f, 0.0f, 0.0f};

    float mat33_t_R[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    //if(*restart)
    //{
    //    fusion_nogyro_inited = 0;
    //}

    accel_data[0] = fusion_accel[0];
    accel_data[1] = fusion_accel[1];
    accel_data[2] = fusion_accel[2];

    float    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);
    accel_data[0] = accel_data[0] / normalize;
    accel_data[1] = accel_data[1] / normalize;
    accel_data[2] = accel_data[2] / normalize;

    float pitch = -atan2f(accel_data[1], accel_data[2]);
    //fusion_nogyro_init_pitch = pitch * TODEG;////俯仰角
    
    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);

    float roll = asinf((-accel_data[0] / normalize));//横滚角
    //fusion_nogyro_init_roll = roll * TODEG;//横滚角
    
    float cp = cosf(pitch);   //roll=0,  pitch=0;      //1
    float sp = sinf(pitch);   //0
    float sr = sinf(roll);    //0
    float cr = cosf(roll);    //  1

    mag_data[0] = fusion_mag[0];
    mag_data[1] = fusion_mag[1];
    mag_data[2] = fusion_mag[2];

    normalize = sqrtf(mag_data[0] * mag_data[0] + mag_data[1] * mag_data[1] + mag_data[2] * mag_data[2]);
    mag_data[0] = mag_data[0] / normalize;
    mag_data[1] = mag_data[1] / normalize;
    mag_data[2] = mag_data[2] / normalize;

    float hx = mag_data[0] * cr + mag_data[2] * sr;
    float hy = -mag_data[0] * sp * sr + mag_data[1] * cp + mag_data[2] * cr * sp;
    float yaw = -atan2f(hx, hy);

    //fusion_nogyro_init_yaw = yaw * TODEG;
    //if(fusion_nogyro_init_yaw < 0.0f)
    //{
    //    fusion_nogyro_init_yaw += 360.0f;
    //}

    //D("inited: %d; %d; %d\r\n", (int)fusion_nogyro_init_pitch, (int)fusion_nogyro_init_roll, (int)fusion_nogyro_init_yaw);
    float sy = sinf(yaw);
    float cy = cosf(yaw);

    // 1 yaw       2 roll   3 pitch
    mat33_t_R[0][0] = cy * cr;
    mat33_t_R[0][1] = -(cy * sr * sp - cp * sy);
    mat33_t_R[0][2] = sy * sp + cy * cp * sy;

    mat33_t_R[1][0] = -(cr * sy);
    mat33_t_R[1][1] = cy * cp + sy * sr * sp;
    mat33_t_R[1][2] = -(cp * sy * sr - cy * sp);

    mat33_t_R[2][0] = -sr;
    mat33_t_R[2][1] = -(cr * sp);
    mat33_t_R[2][2] = cr * cp;

    fusion_nogyro_q_init[0] = sqrtf(clamp( mat33_t_R[0][0] - mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nogyro_q_init[1] = sqrtf(clamp(-mat33_t_R[0][0] + mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nogyro_q_init[2] = sqrtf(clamp(-mat33_t_R[0][0] - mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nogyro_q_init[3] = sqrtf(clamp( mat33_t_R[0][0] + mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);

    fusion_nogyro_q_init[0] = copysignf(fusion_nogyro_q_init[0], mat33_t_R[2][1] - mat33_t_R[1][2]);
    fusion_nogyro_q_init[1] = copysignf(fusion_nogyro_q_init[1], mat33_t_R[0][2] - mat33_t_R[2][0]);
    fusion_nogyro_q_init[2] = copysignf(fusion_nogyro_q_init[2], mat33_t_R[1][0] - mat33_t_R[0][1]);
    
    float q_length =  sqrtf(fusion_nogyro_q_init[0] * fusion_nogyro_q_init[0] + fusion_nogyro_q_init[1] * fusion_nogyro_q_init[1] + fusion_nogyro_q_init[2] * fusion_nogyro_q_init[2] + fusion_nogyro_q_init[3] * fusion_nogyro_q_init[3]);//归一化
    fusion_nogyro_q_init[0] = fusion_nogyro_q_init[0] / q_length;
    fusion_nogyro_q_init[1] = fusion_nogyro_q_init[1] / q_length;
    fusion_nogyro_q_init[2] = fusion_nogyro_q_init[2] / q_length;
    fusion_nogyro_q_init[3] = fusion_nogyro_q_init[3] / q_length;
        
    if(/*isfinite(fusion_nogyro_q_init[0]) && isfinite(fusion_nogyro_q_init[1]) &&
        isfinite(fusion_nogyro_q_init[2]) && isfinite(fusion_nogyro_q_init[3]) &&*/
        q_length > 0.95f && q_length < 1.05f) 
    {
        fusion_nogyro_q0 = fusion_nogyro_q_init[3];
        fusion_nogyro_q1 = fusion_nogyro_q_init[0];
        fusion_nogyro_q2 = fusion_nogyro_q_init[1];
        fusion_nogyro_q3 = fusion_nogyro_q_init[2];
        fusion_nogyro_inited = 1;
    }
    else
    {
        fusion_9axis_inited = 0;
    }

//    fusion_9axis_q0 = fusion_9axis_q_init[3];
//    fusion_9axis_q1 = fusion_9axis_q_init[0];
//    fusion_9axis_q2 = fusion_9axis_q_init[1];
//    fusion_9axis_q3 = fusion_9axis_q_init[2];

    qst_fusion_nogyro_rotation_matrix();
}

#if 0
void qst_fusion_nogyro_angle(float *rpy)
{
    float roll  = asinf(fusion_nogyro_rot_mat[2][0]) * TODEG;
    float pitch = -atan2f(fusion_nogyro_rot_mat[2][1], fusion_nogyro_rot_mat[2][2]) * TODEG;
    float yaw = -atan2f(fusion_nogyro_rot_mat[1][0], fusion_nogyro_rot_mat[0][0]) * TODEG;

    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}
#endif

void qst_fusion_nogyro_get_quaternion(float quat[4])
{
    const float Hx = fusion_nogyro_rot_mat[0][0];
    const float My = fusion_nogyro_rot_mat[1][1];
    const float Az = fusion_nogyro_rot_mat[2][2];
    quat[0] = sqrtf( clamp( Hx - My - Az + 1) * 0.25f );
    quat[1] = sqrtf( clamp(-Hx + My - Az + 1) * 0.25f );
    quat[2] = sqrtf( clamp(-Hx - My + Az + 1) * 0.25f );
    quat[3] = sqrtf( clamp( Hx + My + Az + 1) * 0.25f );
    quat[0] = copysignf(quat[0], fusion_nogyro_rot_mat[2][1] - fusion_nogyro_rot_mat[1][2]);
    quat[1] = copysignf(quat[1], fusion_nogyro_rot_mat[0][2] - fusion_nogyro_rot_mat[2][0]);
    quat[2] = copysignf(quat[2], fusion_nogyro_rot_mat[1][0] - fusion_nogyro_rot_mat[0][1]);
}

void qst_fusion_nogyro_angle(float *rpy)
{
    float roll  = asinf(fusion_nogyro_rot_mat[2][0]) * TODEG;
    float pitch = -atan2f(fusion_nogyro_rot_mat[2][1], fusion_nogyro_rot_mat[2][2]) * TODEG;
    float yaw = -atan2f(fusion_nogyro_rot_mat[1][0], fusion_nogyro_rot_mat[0][0]) * TODEG;

    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}


void qst_fusion_gravity(float gra_data[3],int mode)
{
	if(mode == 1)
	{
        gra_data[0] = fusion_9axis_rot_mat[2][0] * GRAVITY_MSS;
        gra_data[1] = fusion_9axis_rot_mat[2][1] * GRAVITY_MSS;
        gra_data[2] = fusion_9axis_rot_mat[2][2] * GRAVITY_MSS;
	}
    else if(mode == 2)
	{
        gra_data[0] = fusion_nomag_rot_mat[2][0] * GRAVITY_MSS;
        gra_data[1] = fusion_nomag_rot_mat[2][1] * GRAVITY_MSS;
        gra_data[2] = fusion_nomag_rot_mat[2][2] * GRAVITY_MSS;
    }
	else
	{
        gra_data[0] = fusion_nogyro_rot_mat[2][0] * GRAVITY_MSS;
        gra_data[1] = fusion_nogyro_rot_mat[2][1] * GRAVITY_MSS;
        gra_data[2] = fusion_nogyro_rot_mat[2][2] * GRAVITY_MSS;
    }
}

#if 0
void qst_fusion_get_matrix(float matrix[9],int mode)
{
    float *matrix_ptr = NULL;

    if(mode == 0)
        matrix_ptr = (float *)fusion_9axis_rot_mat;
    else if(mode == 1)
        matrix_ptr = (float *)fusion_nomag_rot_mat;
    else if(mode == 2)
        matrix_ptr = (float *)fusion_nogyro_rot_mat;
    else
        matrix_ptr = NULL;

    if(matrix_ptr)
    {
        matrix[0] = matrix_ptr[0];
        matrix[1] = matrix_ptr[1];
        matrix[2] = matrix_ptr[2];
        matrix[3] = matrix_ptr[3];
        matrix[4] = matrix_ptr[4];
        matrix[5] = matrix_ptr[5];
        matrix[6] = matrix_ptr[6];
        matrix[7] = matrix_ptr[7];
        matrix[8] = matrix_ptr[8];
    }
}

void qst_fusion_get_quat(float quat[4],int mode)
{
    if(mode == 0)    // 9axis
        qst_fusion_9axis_euler_to_quaternion(quat);
    else if(mode == 1)    //    a+g
        qst_fusion_nomag_euler_to_quaternion(quat);
    else if(mode == 2)    // a+m
        qst_fusion_nogyro_euler_to_quaternion(quat);
}
#endif
