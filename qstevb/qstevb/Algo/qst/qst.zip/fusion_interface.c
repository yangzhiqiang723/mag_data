
#include <stdio.h>
#include <math.h>
#include "fusion_interface.h"
#include "ical_qst.h"
#include "dummyGyro.h"

#include "qstLog.h"

#define QST_FUSION_EN			1
#define QST_MAG_CALI_EN			1
#define QST_DUMMY_GYRO_EN		0

#define QST_ACC_FILTER
#define QST_MAG_FILTER

typedef struct
{
	int			mode;
	float		acc[3];
	float		acc_f[3];
	float		gyr[3];
	float		mag[3];
	float		mag_f[3];
	float		mag_offset[3];
	float		gravity[3];
	float		dummy_gyr[3];
	unsigned char mag_accury;
	unsigned long long	tm_acc;
	unsigned long long	tm_gyr;	
	unsigned long long	tm_mag;
}qst_fusion_t;

#define AVG_ARRAY_SIZE		6
typedef struct
{
	char	init;
	float	array[AVG_ARRAY_SIZE];
	//float	avg;
}AvgFilter_t;

#define DG_AVG_ARRAY_SIZE		30
typedef struct
{
	char	init;
	float	array[DG_AVG_ARRAY_SIZE];
	//float	avg;
}DgAvgFilter_t;

void qst_fusion_9axis_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart);
void qst_fusion_9axis_get_quaternion(float quat[4]);
void qst_fusion_9axis_angle(float *rpy);

void qst_fusion_nomag_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart);
void qst_fusion_nomag_get_quaternion(float quat[4]);
void qst_fusion_nomag_angle(float *rpy);

void qst_fusion_nogyro_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart);
void qst_fusion_nogyro_get_quaternion(float quat[4]);
void qst_fusion_nogyro_angle(float *rpy);

void qst_fusion_gravity(float gra_data[3],int mode);

#if QST_MAG_CALI_EN
extern int convert_magnetic(float *raw, float *result,float *offset,float *RR,signed char *accuracy);
extern int qst_ori_progress(float *Acc,float *Mag,float *Ori,signed char *accuracy);
extern void qst_ical_init(float *calipara);
#endif
#if QST_DUMMY_GYRO_EN
void QST_fussion_PG(float *Acc, float *Mag, float *Vgyro, long long timeStamp,int reopen_flag);
#endif

static qst_fusion_t	gFusion;
#if defined(QST_ACC_FILTER)
static AvgFilter_t acc_avg[3];
#endif
#if defined(QST_MAG_FILTER)
static AvgFilter_t mag_avg[3];
#endif
#if QST_DUMMY_GYRO_EN
static DgAvgFilter_t dg_acc_avg[3];
static DgAvgFilter_t dg_mag_avg[3];
#endif

static struct virtual_gyro_matrix matrix_3 = { {
	{1, 0, 0},
	{0, 1, 0},
	{0, 0, 1},
} };


#if 1
static void InitAvgFilter(AvgFilter_t *filter)
{
	filter->init = 0;
}

static float ExeAvgFilter(AvgFilter_t *filter, float in)
{
	int i;
	float sum = 0.0f;
	float avg;

	if(filter->init == 0)
	{
		for(i=0; i<AVG_ARRAY_SIZE; i++)
		{
			filter->array[i] = in;
		}
		filter->init = 1;
	}

	sum = 0.0f;;
	for(i=1; i<AVG_ARRAY_SIZE; i++)
	{
		sum += filter->array[i];
		filter->array[i-1] = filter->array[i];
	}
	filter->array[AVG_ARRAY_SIZE-1] = in;
	sum += in;
	avg = sum/AVG_ARRAY_SIZE;

	return avg;
}
#endif


#if QST_DUMMY_GYRO_EN
static void InitDgAvgFilter(DgAvgFilter_t *filter)
{
	filter->init = 0;
}

static float ExeDgAvgFilter(DgAvgFilter_t *filter, float in)
{
	int i;
	float sum = 0.0f;
	float avg;

	if(filter->init == 0)
	{
		for(i=0; i<DG_AVG_ARRAY_SIZE; i++)
		{
			filter->array[i] = in;
		}
		filter->init = 1;
	}

	sum = 0.0f;;
	for(i=1; i<DG_AVG_ARRAY_SIZE; i++)
	{
		sum += filter->array[i];
		filter->array[i-1] = filter->array[i];
	}
	filter->array[DG_AVG_ARRAY_SIZE-1] = in;
	sum += in;
	avg = sum/DG_AVG_ARRAY_SIZE;

	return avg;
}
#endif

static int qst_calc_gravity(float acc[3])
{
#if !QST_FUSION_EN
	static unsigned char gravity_init = 0;
	
    if(gravity_init == 0)
    {
        gravity_init = 1;
        gFusion.gravity[0] = acc[0];
        gFusion.gravity[1] = acc[1];
        gFusion.gravity[2] = acc[2];
    }
    else
    {
        gFusion.gravity[0] = gFusion.gravity[0]*0.8f + acc[0]*0.2f;
        gFusion.gravity[1] = gFusion.gravity[1]*0.8f + acc[1]*0.2f;
        gFusion.gravity[2] = gFusion.gravity[2]*0.8f + acc[2]*0.2f;
    }
#endif
	return 0;
}

static void qst_fusion_reset(void)
{
#if defined(QST_ACC_FILTER)
	InitAvgFilter(&acc_avg[0]);
	InitAvgFilter(&acc_avg[1]);
	InitAvgFilter(&acc_avg[2]);
#endif
#if defined(QST_MAG_FILTER)
	InitAvgFilter(&mag_avg[0]);
	InitAvgFilter(&mag_avg[1]);
	InitAvgFilter(&mag_avg[2]);
#endif
#if QST_DUMMY_GYRO_EN
	InitDgAvgFilter(&dg_acc_avg[0]);
	InitDgAvgFilter(&dg_acc_avg[1]);
	InitDgAvgFilter(&dg_acc_avg[2]);
	InitDgAvgFilter(&dg_mag_avg[0]);
	InitDgAvgFilter(&dg_mag_avg[1]);
	InitDgAvgFilter(&dg_mag_avg[2]);
#endif
	gFusion.acc[0] = gFusion.acc_f[0] = 0.0f;
	gFusion.acc[1] = gFusion.acc_f[1] = 0.0f;
	gFusion.acc[2] = gFusion.acc_f[2] = 9.807f;
}

static int qst_fusion_write_nvram(float *pData, int len)
{
	return 0;
}

static int qst_fusion_read_nvram(float *pData, int len)
{
	return 0;
}

static int qst_mag_cali_init(void)
{
#if QST_MAG_CALI_EN
	float magPara[4] = {0.0, 0.0, 0.0, 0.0};

	qst_fusion_read_nvram(magPara, sizeof(magPara));
	qst_ical_init(magPara);
#endif
	return 0;
}

static int qst_fusion_enableLib(int mode)
{
	qst_fusion_reset();
	qst_mag_cali_init();
	gFusion.mode = mode;
	return 0;
}

static int qst_fusion_SetGyroData(libData *inputData)
{
	unsigned long long timeStamp = inputData->timeStamp;
	float dt=0.0f;

	gFusion.gyr[0] = inputData->x;
	gFusion.gyr[1] = inputData->y;
	gFusion.gyr[2] = inputData->z;

	dt = (float)(timeStamp-gFusion.tm_gyr)/1000000000;
	if(dt > 0.1f || dt < 0.0f)
	{
		dt = 0.0f;
	}
	gFusion.tm_gyr = timeStamp;
	//LOGD("qst-9d %f	%f	%f", gFusion.mag[0],gFusion.mag[1],gFusion.mag[2]);
	//LOGD("qst-9d %f	%f	%f", gFusion.acc[0],gFusion.acc[1],gFusion.acc[2]);
	//LOGD("qst-9d %f	%f	%f	dt=%f	%lld",gFusion.gyr[0],gFusion.gyr[1],gFusion.gyr[2],dt,inputData->timeStamp);

#if QST_FUSION_EN
	if(gFusion.mode == FUSION_9AXIS)
	{
		qst_fusion_9axis_update(&gFusion.acc_f[0], &gFusion.gyr[0], &gFusion.mag_f[0], &dt, NULL);
	}
	else if(gFusion.mode == FUSION_NOMAG)
	{
		qst_fusion_nomag_update(&gFusion.acc_f[0], &gFusion.gyr[0], &gFusion.mag_f[0], &dt, NULL);
	}
#endif
	return 0;
}

static int qst_fusion_SetAccData(libData *inputData)
{
	unsigned long long timeStamp = inputData->timeStamp;
	float dt=0.0f;

	gFusion.acc[0] = inputData->x;
	gFusion.acc[1] = inputData->y;
	gFusion.acc[2] = inputData->z;
#if defined(QST_ACC_FILTER)
	gFusion.acc_f[0] = ExeAvgFilter(&acc_avg[0], gFusion.acc[0]);
	gFusion.acc_f[1] = ExeAvgFilter(&acc_avg[1], gFusion.acc[1]);
	gFusion.acc_f[2] = ExeAvgFilter(&acc_avg[2], gFusion.acc[2]);
#else
	gFusion.acc_f[0] = gFusion.acc[0];
	gFusion.acc_f[1] = gFusion.acc[1];
	gFusion.acc_f[2] = gFusion.acc[2];
#endif
	dt = (float)(timeStamp-gFusion.tm_acc)/1000000000;
	if(dt > 0.1f || dt <0.0f)
	{
		dt = 0.0f;
	}
	gFusion.tm_acc = timeStamp;

	qst_calc_gravity(gFusion.acc);
#if QST_FUSION_EN
	if(gFusion.mode == FUSION_NOGYRO)
	{
		qst_fusion_nogyro_update(&gFusion.acc_f[0], &gFusion.gyr[0], &gFusion.mag_f[0], &dt, NULL);
	}
#endif
#if QST_DUMMY_GYRO_EN
	{
		float acc[3];
		float mag[3];

		acc[0] = gFusion.acc[0]*1000;
		acc[1] = gFusion.acc[1]*1000;
		acc[2] = gFusion.acc[2]*1000;
		mag[0] = gFusion.mag[0];
		mag[1] = gFusion.mag[1];
		mag[2] = gFusion.mag[2];

		acc[0] = ExeDgAvgFilter(&dg_acc_avg[0], acc[0]);
		acc[1] = ExeDgAvgFilter(&dg_acc_avg[1], acc[1]);
		acc[2] = ExeDgAvgFilter(&dg_acc_avg[2], acc[2]);
		
		mag[0] = ExeDgAvgFilter(&dg_mag_avg[0], mag[0]);
		mag[1] = ExeDgAvgFilter(&dg_mag_avg[1], mag[1]);
		mag[2] = ExeDgAvgFilter(&dg_mag_avg[2], mag[2]);
		QST_fussion_PG(acc, mag, gFusion.dummy_gyr, gFusion.tm_acc, 0);
	}
#endif

	return 0;
}

static int qst_fusion_SetMagData(libData *inputData)
{
#if 0
	// set mag calied data
	gFusion.mag[0] = inputData->x;
	gFusion.mag[1] = inputData->y;
	gFusion.mag[2] = inputData->z;
#if defined(QST_MAG_FILTER)
	gFusion.mag_f[0] = ExeAvgFilter(&mag_avg[0], gFusion.mag[0]);
	gFusion.mag_f[1] = ExeAvgFilter(&mag_avg[1], gFusion.mag[1]);
	gFusion.mag_f[2] = ExeAvgFilter(&mag_avg[2], gFusion.mag[2]);
#else
	gFusion.mag_f[0] = gFusion.mag[0];
	gFusion.mag_f[1] = gFusion.mag[1];
	gFusion.mag_f[2] = gFusion.mag[2];
#endif

#endif
	return 0;
}

static int qst_fusion_GetMagOffset(float offset[3])
{
	offset[0] = gFusion.mag_offset[0];
	offset[1] = gFusion.mag_offset[1];
	offset[2] = gFusion.mag_offset[2];

	return 0;
}

static int qst_fusion_doCali(libData *inputData, libData *outputData)
{
#if QST_MAG_CALI_EN
	float mag[3], mag_cal[3], offset[3];
	float rr;
	signed char accuracy;
	extern int convert_magnetic(float *raw, float *result,float *offset,float *RR,signed char *accuracy);

	mag_cal[0] = mag[0] = inputData->x;
	mag_cal[1] = mag[1] = inputData->y;
	mag_cal[2] = mag[2] = inputData->z;
	convert_magnetic(mag, mag_cal, offset, &rr, &accuracy);
	gFusion.tm_mag = inputData->timeStamp;
	gFusion.mag[0] = mag_cal[0];
	gFusion.mag[1] = mag_cal[1];
	gFusion.mag[2] = mag_cal[2];
	gFusion.mag_offset[0] = offset[0];
	gFusion.mag_offset[1] = offset[1];
	gFusion.mag_offset[2] = offset[2];
#if defined(QST_MAG_FILTER)
	gFusion.mag_f[0] = ExeAvgFilter(&mag_avg[0], mag_cal[0]);
	gFusion.mag_f[1] = ExeAvgFilter(&mag_avg[1], mag_cal[1]);
	gFusion.mag_f[2] = ExeAvgFilter(&mag_avg[2], mag_cal[2]);
#else
	gFusion.mag_f[0] = gFusion.mag[0];
	gFusion.mag_f[1] = gFusion.mag[1];
	gFusion.mag_f[2] = gFusion.mag[2];
#endif
	outputData->x = gFusion.mag_f[0];
	outputData->y = gFusion.mag_f[1];
	outputData->z = gFusion.mag_f[2];
	outputData->w = rr;
	outputData->status = accuracy;
	outputData->timeStamp = inputData->timeStamp;

	if((gFusion.mag_accury < 3) && (accuracy >= 3))
	{
		float magPara[4] = {0.0, 0.0, 0.0, 0.0};

		magPara[0] = gFusion.mag_offset[0];
		magPara[1] = gFusion.mag_offset[1];
		magPara[2] = gFusion.mag_offset[2];
		magPara[3] = rr;
		qst_fusion_write_nvram(magPara, sizeof(magPara));
	}
	gFusion.mag_accury = accuracy;
#else
	outputData->status = inputData->status;
	outputData->timeStamp = inputData->timeStamp;
	outputData->x = inputData->x;
	outputData->y = inputData->y;
	outputData->z = inputData->z;
#endif
	return 0;
}

static int qst_fusion_getGravity(libData *outputData)
{
	float gravity[3];

#if QST_FUSION_EN
	if(gFusion.mode == FUSION_9AXIS)
	{
		qst_fusion_gravity(gravity, 1);
	}	
	else if(gFusion.mode == FUSION_NOMAG)
	{
		qst_fusion_gravity(gravity, 2);
	}
	else if(gFusion.mode == FUSION_NOGYRO)
	{
		qst_fusion_gravity(gravity, 3);
	}
	gFusion.gravity[0] = gravity[0];
	gFusion.gravity[1] = gravity[1];
	gFusion.gravity[2] = gravity[2];
#else
	gravity[0] = gFusion.gravity[0];
	gravity[1] = gFusion.gravity[1];
	gravity[2] = gFusion.gravity[2];
#endif
	outputData->status = 3;
	outputData->timeStamp = gFusion.tm_acc;
	outputData->x = gravity[0];
	outputData->y = gravity[1];
	outputData->z = gravity[2];
	
	return 0;
}

static int qst_fusion_getRotationVector(libData *outputData)
{
#if QST_FUSION_EN
	float quat[4] = {0,0,0,1};

	if(gFusion.mode == FUSION_9AXIS)
	{
		qst_fusion_9axis_get_quaternion(quat);
		outputData->timeStamp = gFusion.tm_gyr;
	}
	else if(gFusion.mode == FUSION_NOMAG)
	{
		qst_fusion_nomag_get_quaternion(quat);		
		outputData->timeStamp = gFusion.tm_gyr;
	}
	else if(gFusion.mode == FUSION_NOGYRO)
	{
		qst_fusion_nogyro_get_quaternion(quat);
		outputData->timeStamp = gFusion.tm_acc;
	}
	
	outputData->x = quat[0];
	outputData->y = quat[1];
	outputData->z = quat[2];
	outputData->w = quat[3];
	outputData->status = 3;
#endif

	return 0;
}

static int qst_fusion_getOrientation(libData *outputData)
{
	float euler[3];
	signed char accuracy = 3;

#if QST_FUSION_EN
	if(gFusion.mode == FUSION_9AXIS)
	{
		qst_fusion_9axis_angle(euler);		
	}	
	else if(gFusion.mode == FUSION_NOMAG)
	{
		qst_fusion_nomag_angle(euler);
	}
	else if(gFusion.mode == FUSION_NOGYRO)
	{		
		#if QST_MAG_CALI_EN
		qst_ori_progress(gFusion.acc_f, gFusion.mag_f, euler, &accuracy);
		#else
		qst_fusion_nogyro_angle(euler);
		#endif	
	}
#else
	#if QST_MAG_CALI_EN
		qst_ori_progress(gFusion.acc_f, gFusion.mag_f, euler, &accuracy);
	#endif	
#endif
	
	outputData->status = accuracy;
	outputData->timeStamp = gFusion.tm_acc;
	outputData->x = euler[0];
	outputData->y = euler[1];
	outputData->z = euler[2];

	return 0;
}

static int qst_fusion_getLinearaccel(libData *outputData)
{
	float gravity[3];

#if QST_FUSION_EN
	if(gFusion.mode == FUSION_9AXIS)
	{
		qst_fusion_gravity(gravity, 1);
	}	
	else if(gFusion.mode == FUSION_NOMAG)
	{
		qst_fusion_gravity(gravity, 2);
	}
	else if(gFusion.mode == FUSION_NOGYRO)
	{
		qst_fusion_gravity(gravity, 3);
	}
	gFusion.gravity[0] = gravity[0];
	gFusion.gravity[1] = gravity[1];
	gFusion.gravity[2] = gravity[2];
#endif

	gravity[0] = gFusion.acc[0] - gFusion.gravity[0];
	gravity[1] = gFusion.acc[1] - gFusion.gravity[1];
	gravity[2] = gFusion.acc[2] - gFusion.gravity[2];
	outputData->status = 3;
	outputData->timeStamp = gFusion.tm_acc;
	outputData->x = gravity[0];
	outputData->y = gravity[1];
	outputData->z = gravity[2];
	
	return 0;
}

static int qst_fusion_getGameRotationVector(libData *outputData)
{
#if QST_FUSION_EN
	if(gFusion.mode == FUSION_NOMAG)
	{
		float quat[4];
		qst_fusion_nomag_get_quaternion(quat);		
		outputData->x = quat[0];
		outputData->y = quat[1];
		outputData->z = quat[2];
		outputData->w = quat[3];
		outputData->status = 3;
		outputData->timeStamp = gFusion.tm_gyr;
	}
#endif
	return 0;
}

static int qst_fusion_getGeoMagnetic(libData *outputData)
{
#if QST_FUSION_EN
	if(gFusion.mode == FUSION_NOGYRO)
	{
		float quat[4];
		qst_fusion_nogyro_get_quaternion(quat);
		outputData->x = quat[0];
		outputData->y = quat[1];
		outputData->z = quat[2];
		outputData->w = quat[3];
		outputData->status = 3;
		outputData->timeStamp = gFusion.tm_acc;
	}
#endif
	return 0;
}

static int qst_fusion_getVirtualGyro(libData *outputData)
{
#if QST_DUMMY_GYRO_EN
	outputData->status = 3;
	outputData->timeStamp = gFusion.tm_acc;
	outputData->x = gFusion.dummy_gyr[0];
	outputData->y = gFusion.dummy_gyr[1];
	outputData->z = gFusion.dummy_gyr[2];
#endif

	return 0;
}

struct qst_fusion_interface_t algo_qst_fusion = 
{
	.version = "1.01",
	.enableLib = qst_fusion_enableLib,
	.SetGyroData = qst_fusion_SetGyroData,
	.SetAccData = qst_fusion_SetAccData,
	.SetMagData = qst_fusion_SetMagData,
	.GetMagOffset = qst_fusion_GetMagOffset,
	.doCali = qst_fusion_doCali,
	.getGravity = qst_fusion_getGravity,
	.getRotationVector = qst_fusion_getRotationVector,
	.getOrientation = qst_fusion_getOrientation,
	.getLinearaccel = qst_fusion_getLinearaccel,
	.getGameRotationVector = qst_fusion_getGameRotationVector,
	.getGeoMagnetic = qst_fusion_getGeoMagnetic,
	.getVirtualGyro = qst_fusion_getVirtualGyro
};

void qst_fusion_get_interface(struct qst_fusion_interface_t **p_algo) 
{
	*p_algo = &algo_qst_fusion;
}


