#ifndef QST_LOG_H
#define QST_LOG_H


//#define USE_ANDROID_STUDIO
//#define USE_ANDROID_PLATFORM
#define USE_MCU_PLATFORM

//#define QST_ALGO_DEBUG
#if defined(QST_ALGO_DEBUG)

#undef TAG
#define TAG			"qst-core"

#if defined(USE_ANDROID_STUDIO)
	#include <android/log.h>
	
	#define  D(...)  		__android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__)
	#define  E(...)			__android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__)
	#define LOGD(...)		__android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__)
	#define LOGI(...)		__android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__)
	#define LOGW(...)		__android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__)
	#define LOGE(...)		__android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__)
	#define LOGF(...)		__android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__)
#elif defined(USE_ANDROID_PLATFORM)
	#include <log/log.h>
	//#include <cutils/log.h>
	#define  D(...) 		ALOGD(__VA_ARGS__)
	#define  E(...) 		ALOGE(__VA_ARGS__)
	#define LOGD(...)		ALOGD(__VA_ARGS__)
	#define LOGI(...)		ALOGI(__VA_ARGS__)
	#define LOGW(...)		ALOGW(__VA_ARGS__)
	#define LOGE(...)		ALOGE(__VA_ARGS__)
	#define LOGF(...)		ALOGF(__VA_ARGS__)
#elif defined(USE_MCU_PLATFORM)
	#define  D(...) 		printf(__VA_ARGS__)
	#define  E(...) 		printf(__VA_ARGS__)
	#define LOGD(...)		printf(__VA_ARGS__)
	#define LOGI(...)		printf(__VA_ARGS__)
	#define LOGW(...)		printf(__VA_ARGS__)
	#define LOGE(...)		printf(__VA_ARGS__)
	#define LOGF(...)		printf(__VA_ARGS__)
#else
	#define  D(...)
	#define  E(...)
	#define LOGD(...)
	#define LOGI(...)
	#define LOGW(...)
	#define LOGE(...)
	#define LOGF(...)
#endif

#else
#define LOGD(...)
#define LOGI(...)
#define LOGW(...)
#define LOGE(...)
#define LOGF(...)
#endif

#endif

