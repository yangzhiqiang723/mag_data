#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
//#include "imualgo_axis6.h"
//#include "ICAL_GDF30X.h"
#include "qstLog.h"

//#define IMUALGO_LOG

#define LPF_ALPHA           0.8f
#define MAX_CALI_COUNT      50
#define QST_FABS(v)            ((v<0)?(-1.0f*v):(v))
#define QST_ABS(v)            ((v<0)?(-1*v):(v))
#define Pi                    3.14159265f
#define TODEG                57.2957796f
#define GRAVITY_MSS            9.80665f

#define clamp(v) ((v) < 0 ? 0 : (v))

float fusion_9axis_q0 = 1.0f;
float fusion_9axis_q1 = 0.0f;
float fusion_9axis_q2 = 0.0f;
float fusion_9axis_q3 = 0.0f;

float fusion_9axis_kp = 4.0f;
float fusion_9axis_mag_kp = 6.0f;

float fusion_9axis_ki = 0.1f;
float fusion_9axis_Int_max = 0.05f;
float fusion_9axis_exInt = 0;
float fusion_9axis_eyInt = 0;
float fusion_9axis_ezInt = 0;

float fusion_9axis_rot_mat[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};

float fusion_9axis_quaternion[4]= {1, 0, 0, 0};

/****************** žùŸÝ³õÊŒ»¯Å·À­œÇ³õÊŒ»¯ËÄÔªÊý *****************************/
unsigned char fusion_9axis_inited = 0;
unsigned char fusion_nomag_inited = 0;
float fusion_9axis_q_init[4] = {0, 0, 0, 0};


//constrain a value
float constrain_float(float amt, float low, float high) 
{
    return ((amt) < (low) ? (low) : ((amt) > (high) ? (high) : (amt)));
}
float min(float a, float b)
{
	return (a < b) ? a : b;
}
/*
  wrap an angle defined in radians to -PI ~ PI (equivalent to +- 180 degrees)
 */
float wrap_PI(float angle_in_radians)
{
    while (angle_in_radians > Pi) 
    {
        angle_in_radians -= 2.0f * Pi;
    }
    while (angle_in_radians < -Pi) 
    {
        angle_in_radians += 2.0f * Pi;
    }
    return angle_in_radians;
}



void qst_fusion_9axis_rotation_matrix(void)
{
    float q1q1 = fusion_9axis_q1 * fusion_9axis_q1;
    float q2q2 = fusion_9axis_q2 * fusion_9axis_q2;
    float q3q3 = fusion_9axis_q3 * fusion_9axis_q3;

    float q1q2 = fusion_9axis_q1 * fusion_9axis_q2;
    float q0q3 = fusion_9axis_q0 * fusion_9axis_q3;
    float q1q3 = fusion_9axis_q1 * fusion_9axis_q3;

    float q0q2 = fusion_9axis_q0 * fusion_9axis_q2;
    float q2q3 = fusion_9axis_q2 * fusion_9axis_q3;
    float q0q1 = fusion_9axis_q0 * fusion_9axis_q1;

    fusion_9axis_rot_mat[0][0] = 1 - 2 * (q2q2 + q3q3);
    fusion_9axis_rot_mat[0][1] = 2 * (q1q2 - q0q3);
    fusion_9axis_rot_mat[0][2] = 2 * (q1q3 + q0q2);

    fusion_9axis_rot_mat[1][0] = 2 * (q1q2 + q0q3);
    fusion_9axis_rot_mat[1][1] = 1 - 2 * (q1q1 + q3q3);
    fusion_9axis_rot_mat[1][2] = 2 * (q2q3 - q0q1);

    fusion_9axis_rot_mat[2][0] = 2 * (q1q3 - q0q2);
    fusion_9axis_rot_mat[2][1] = 2 * (q2q3 + q0q1);
    fusion_9axis_rot_mat[2][2] = 1-2 * (q1q1 + q2q2);
}

//static float old_yaw_9axis = 0;
unsigned char qst_fusion_9axis_init(float accel_in[3], float mag_in[3]) 
{
    float accel_data[3] = {0, 0, 0};
    float mag_data[3] = {0, 0, 0};

    float mat33_t_R[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    accel_data[0] = accel_in[0];
    accel_data[1] = accel_in[1];
    accel_data[2] = accel_in[2];

    float normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);
    accel_data[0] = accel_data[0] / normalize;
    accel_data[1] = accel_data[1] / normalize;
    accel_data[2] = accel_data[2] / normalize;

    float pitch = -atan2f(accel_data[1], accel_data[2]);
    //fusion_9axis_init_pitch = pitch * TODEG;////俯仰角

    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);

    float roll = asinf((accel_data[0] / normalize));//ºá¹öœÇ
    //fusion_9axis_init_roll = roll * TODEG;//ºá¹öœÇ

    float cp = cosf(pitch);   //roll=0,  pitch=0;      //1
    float sp = sinf(pitch);                                 //0
    float sr = sinf(roll);                                     //0
    float cr = cosf(roll);                                   //  1

    mag_data[0] = mag_in[0];
    mag_data[1] = mag_in[1];
    mag_data[2] = mag_in[2];

    normalize = sqrtf(mag_data[0] * mag_data[0] + mag_data[1] * mag_data[1] + mag_data[2] * mag_data[2]);
    mag_data[0] = mag_data[0] / normalize;
    mag_data[1] = mag_data[1] / normalize;
    mag_data[2] = mag_data[2] / normalize;

    float hx = mag_data[0] * cr - mag_data[2] * sr;
    float hy = mag_data[0] * sp * sr + mag_data[1] * cp + mag_data[2] * cr * sp;
    float yaw = 0;//-atan2f(hx, hy);
    yaw = -atan2f(hx, hy);
    float sy = 0;
    float cy = 0;
#if 0//def USING_ACC_LOCK
    int acc_lock_en = 0;
    get_acc_lock_status(&acc_lock_en);
    if(acc_lock_en){
        yaw = old_yaw_9axis;
    }else{
        old_yaw_9axis = yaw;
    }
#endif
    sy = sinf(yaw);
    cy = cosf(yaw);

    // 1 yaw       2 roll   3 pitch
    mat33_t_R[0][0] = cy * cr;
    mat33_t_R[0][1] = -(cy * sr * sp - cp * sy);
    mat33_t_R[0][2] = sy * sp + cy * cp * sy;

    mat33_t_R[1][0] = -(cr * sy);
    mat33_t_R[1][1] = cy * cp + sy * sr * sp;
    mat33_t_R[1][2] = -(cp * sy * sr - cy * sp);

    mat33_t_R[2][0] = -sr;
    mat33_t_R[2][1] = -(cr * sp);
    mat33_t_R[2][2] = cr * cp;

    fusion_9axis_q_init[0] = sqrtf(clamp( mat33_t_R[0][0] - mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[1] = sqrtf(clamp(-mat33_t_R[0][0] + mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[2] = sqrtf(clamp(-mat33_t_R[0][0] - mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);
    fusion_9axis_q_init[3] = sqrtf(clamp( mat33_t_R[0][0] + mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);

    fusion_9axis_q_init[0] = copysignf(fusion_9axis_q_init[0], mat33_t_R[2][1] - mat33_t_R[1][2]);
    fusion_9axis_q_init[1] = copysignf(fusion_9axis_q_init[1], mat33_t_R[0][2] - mat33_t_R[2][0]);
    fusion_9axis_q_init[2] = copysignf(fusion_9axis_q_init[2], mat33_t_R[1][0] - mat33_t_R[0][1]);

    float q_length =  sqrtf(fusion_9axis_q_init[0] * fusion_9axis_q_init[0] + fusion_9axis_q_init[1]
                      * fusion_9axis_q_init[1] +  fusion_9axis_q_init[2] * fusion_9axis_q_init[2]
                      + fusion_9axis_q_init[3] * fusion_9axis_q_init[3]);//¹éÒ»»¯
    fusion_9axis_q_init[0] = fusion_9axis_q_init[0] / q_length;
    fusion_9axis_q_init[1] = fusion_9axis_q_init[1] / q_length;
    fusion_9axis_q_init[2] = fusion_9axis_q_init[2] / q_length;
    fusion_9axis_q_init[3] = fusion_9axis_q_init[3] / q_length;

    if(/*isfinite(fusion_9axis_q_init[0]) && isfinite(fusion_9axis_q_init[1]) &&
        isfinite(fusion_9axis_q_init[2]) && isfinite(fusion_9axis_q_init[3]) &&*/
        q_length > 0.95f && q_length < 1.05f) 
    {
        fusion_9axis_inited = 1;
    } 
    else
    {
        fusion_9axis_inited = 0;
    }

    fusion_9axis_q0 = fusion_9axis_q_init[3];
    fusion_9axis_q1 = fusion_9axis_q_init[0];
    fusion_9axis_q2 = fusion_9axis_q_init[1];
    fusion_9axis_q3 = fusion_9axis_q_init[2];

    qst_fusion_9axis_rotation_matrix();

    return fusion_9axis_inited;
}




void qst_fusion_9axis_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart)
{
    float ex = 0.0f;
    float ey = 0.0f;
    float ez = 0.0f;

    float integral_dt = *fusion_dt;
    float halfT = 0.5f * integral_dt;

    float accel_tmp[3] = {0.0f, 0.0f, 0.0f};
    float gyro_tmp[3] = {0.0f, 0.0f, 0.0f};
    float mag_tmp[3] = {0.0f, 0.0f, 0.0f};

    accel_tmp[0] = fusion_accel[0];
    accel_tmp[1] = fusion_accel[1];
    accel_tmp[2] = fusion_accel[2];

    gyro_tmp[0] = fusion_gyro[0];
    gyro_tmp[1] = fusion_gyro[1];
    gyro_tmp[2] = fusion_gyro[2];

    if(integral_dt > 0.3f)
    {
        fusion_9axis_inited = 0;
    }
    else
    {
        if(integral_dt < 0.0f || integral_dt > 0.04f)
        {
            integral_dt = 0.005f;
            halfT = 0.5f * integral_dt;
        }
    }

    if(restart&&*restart)
    {
        fusion_9axis_inited = 0;
    }

    if(!fusion_9axis_inited) 
    {
        qst_fusion_9axis_init(accel_tmp, fusion_mag);
        return ;
    }

    mag_tmp[0] = fusion_mag[0];
    mag_tmp[1] = fusion_mag[1];
    mag_tmp[2] = fusion_mag[2];

    accel_tmp[0] = fusion_accel[0];
    accel_tmp[1] = fusion_accel[1];
    accel_tmp[2] = fusion_accel[2];

    gyro_tmp[0] = fusion_gyro[0];
    gyro_tmp[1] = fusion_gyro[1];
    gyro_tmp[2] = fusion_gyro[2];

    float recip_norm = sqrtf(mag_tmp[0] * mag_tmp[0] + mag_tmp[1] * mag_tmp[1] + mag_tmp[2] * mag_tmp[2]);
    float spinRate = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);
    if(recip_norm > 0.01f) 
    {
        // Normalise magnetometer measurement
        mag_tmp[0] = mag_tmp[0] / recip_norm;
        mag_tmp[1] = mag_tmp[1] / recip_norm;
        mag_tmp[2] = mag_tmp[2] / recip_norm;
                
        // Magnetometer correction
        // Project mag field vector to global frame and extract XY component
        float hx = fusion_9axis_rot_mat[0][0] * mag_tmp[0] + fusion_9axis_rot_mat[0][1] * mag_tmp[1] + fusion_9axis_rot_mat[0][2] * mag_tmp[2];
        float hy = fusion_9axis_rot_mat[1][0] * mag_tmp[0] + fusion_9axis_rot_mat[1][1] * mag_tmp[1] + fusion_9axis_rot_mat[1][2] * mag_tmp[2]; 
        float hz = fusion_9axis_rot_mat[2][0] * mag_tmp[0] + fusion_9axis_rot_mat[2][1] * mag_tmp[1] + fusion_9axis_rot_mat[2][2] * mag_tmp[2]; 

        float by = sqrtf(hx * hx + hy * hy);
        float bz = hz;

        //nÏµÖÐµÄµØŽÅÏòÁ¿[bx,by,bz]×ª»»µœbÏµÖÐ£¬µÃµœ[wx,wy,wz]
        float wx = fusion_9axis_rot_mat[1][0] * by + fusion_9axis_rot_mat[2][0] * bz;  
        float wy = fusion_9axis_rot_mat[1][1] * by + fusion_9axis_rot_mat[2][1] * bz;  
        float wz = fusion_9axis_rot_mat[1][2] * by + fusion_9axis_rot_mat[2][2] * bz;  
        
        float fifty_dps =  0.873f;//50dps
		float gainMult = 1.0f;
		if(spinRate > fifty_dps)
		{
			gainMult = min(spinRate / fifty_dps, 2.50f);
		}
		ex = (mag_tmp[1] * wz - mag_tmp[2] * wy) * fusion_9axis_mag_kp * gainMult;
		ey = (mag_tmp[2] * wx - mag_tmp[0] * wz) * fusion_9axis_mag_kp * gainMult;
		ez = (mag_tmp[0] * wy - mag_tmp[1] * wx) * fusion_9axis_mag_kp * gainMult;
    }

    recip_norm = sqrtf(accel_tmp[0] * accel_tmp[0] + accel_tmp[1] * accel_tmp[1] + accel_tmp[2] * accel_tmp[2]);
    if(recip_norm > GRAVITY_MSS * 0.9f && recip_norm <  GRAVITY_MSS * 1.1f)
    {
        accel_tmp[0] = accel_tmp[0] / recip_norm;
        accel_tmp[1] = accel_tmp[1] / recip_norm;
        accel_tmp[2] = accel_tmp[2] / recip_norm;

        ex += (accel_tmp[1] * fusion_9axis_rot_mat[2][2] - accel_tmp[2] * fusion_9axis_rot_mat[2][1]) * fusion_9axis_kp;
        ey += (accel_tmp[2] * fusion_9axis_rot_mat[2][0] - accel_tmp[0] * fusion_9axis_rot_mat[2][2]) * fusion_9axis_kp;
        ez += (accel_tmp[0] * fusion_9axis_rot_mat[2][1] - accel_tmp[1] * fusion_9axis_rot_mat[2][0]) * fusion_9axis_kp;
    }

   // float spinRate = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);
    if(spinRate < 0.175f) //20
    {
        fusion_9axis_exInt += ex * fusion_9axis_ki * integral_dt;
        fusion_9axis_eyInt += ey * fusion_9axis_ki * integral_dt;
        fusion_9axis_ezInt += ez * fusion_9axis_ki * integral_dt;
        fusion_9axis_exInt = constrain_float(fusion_9axis_exInt, -fusion_9axis_Int_max, fusion_9axis_Int_max);
        fusion_9axis_eyInt = constrain_float(fusion_9axis_eyInt, -fusion_9axis_Int_max, fusion_9axis_Int_max);
        fusion_9axis_ezInt = constrain_float(fusion_9axis_ezInt, -fusion_9axis_Int_max, fusion_9axis_Int_max);
    }
    else
    {
        fusion_9axis_exInt = 0.0f;
        fusion_9axis_eyInt = 0.0f;
        fusion_9axis_ezInt = 0.0f;
    }

    gyro_tmp[0] = gyro_tmp[0] + ex + fusion_9axis_exInt;
    gyro_tmp[1] = gyro_tmp[1] + ey + fusion_9axis_eyInt;
    gyro_tmp[2] = gyro_tmp[2] + ez + fusion_9axis_ezInt;

    float qw = fusion_9axis_q0;
    float qx = fusion_9axis_q1;
    float qy = fusion_9axis_q2;
    float qz = fusion_9axis_q3;

    fusion_9axis_q0 += (-qx * gyro_tmp[0] - qy * gyro_tmp[1] - qz * gyro_tmp[2]) * halfT;
    fusion_9axis_q1 += (+qw * gyro_tmp[0] + qy * gyro_tmp[2] - qz * gyro_tmp[1]) * halfT;
    fusion_9axis_q2 += (+qw * gyro_tmp[1] - qx * gyro_tmp[2] + qz * gyro_tmp[0]) * halfT;
    fusion_9axis_q3 += (+qw * gyro_tmp[2] + qx * gyro_tmp[1] - qy * gyro_tmp[0]) * halfT;

    recip_norm = sqrtf(fusion_9axis_q0 * fusion_9axis_q0 + fusion_9axis_q1 * fusion_9axis_q1 + fusion_9axis_q2 * fusion_9axis_q2 + fusion_9axis_q3 * fusion_9axis_q3);
    fusion_9axis_q0 = fusion_9axis_q0 / recip_norm;
    fusion_9axis_q1 = fusion_9axis_q1 / recip_norm;
    fusion_9axis_q2 = fusion_9axis_q2 / recip_norm;
    fusion_9axis_q3 = fusion_9axis_q3 / recip_norm;

    qst_fusion_9axis_rotation_matrix();
}

void qst_fusion_9axis_angle(float *rpy)
{
    float    roll  = asinf(fusion_9axis_rot_mat[2][0]) * TODEG;
    float    pitch = atan2f(-fusion_9axis_rot_mat[2][1], fusion_9axis_rot_mat[2][2]) * TODEG;
    float    yaw = atan2f(-fusion_9axis_rot_mat[1][0], fusion_9axis_rot_mat[0][0]) * TODEG;
    
    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }
    
    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}

void qst_fusion_9axis_get_quaternion(float quat[4])
{
#ifdef QST_SUPPORT_YAW
    float mat33_t_R_yzw[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
#endif
    quat[0] = sqrtf(clamp( fusion_9axis_rot_mat[0][0] - fusion_9axis_rot_mat[1][1] - fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[1] = sqrtf(clamp(-fusion_9axis_rot_mat[0][0] + fusion_9axis_rot_mat[1][1] - fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[2] = sqrtf(clamp(-fusion_9axis_rot_mat[0][0] - fusion_9axis_rot_mat[1][1] + fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[3] = sqrtf(clamp( fusion_9axis_rot_mat[0][0] + fusion_9axis_rot_mat[1][1] + fusion_9axis_rot_mat[2][2] + 1) * 0.25f);
    quat[0] = copysignf(quat[0], fusion_9axis_rot_mat[2][1] - fusion_9axis_rot_mat[1][2]);
    quat[1] = copysignf(quat[1], fusion_9axis_rot_mat[0][2] - fusion_9axis_rot_mat[2][0]);
    quat[2] = copysignf(quat[2], fusion_9axis_rot_mat[1][0] - fusion_9axis_rot_mat[0][1]);
#if defined(QST_SUPPORT_YAW)
    {
        float quat_t[4];
        
        quat_t[0] = quat[3];
        quat_t[1] = quat[0];
        quat_t[2] = quat[1];
        quat_t[3] = quat[2];

        float roll = asinf(2 * (quat_t[1] * quat_t[3] - quat_t[0] * quat_t[2]));
        float pitch = -atan2f(2 * (quat_t[2] * quat_t[3] + quat_t[0] * quat_t[1]), 1 - 2 * (quat_t[1] * quat_t[1] + quat_t[2] * quat_t[2])); 
        //float yaw = -atan2f(2 * (quat_t[1] * quat_t[2] + quat_t[0] * quat_t[3]), 1 - 2 * (quat_t[2] * quat_t[2] + quat_t[3] * quat_t[3]));
        float yaw = atan2f(-2 * (quat_t[1] * quat_t[2] + quat_t[0] * quat_t[3]),  1 - 2 * (quat_t[2] * quat_t[2] + quat_t[3] * quat_t[3]));
        yaw = yaw*TODEG;

        if (yaw  < 0)
            yaw += 360;

        int hope =0;
        hope = (int)((yaw / 45) + 0.5) * 45;



        if(yaw >= (hope - 10) && yaw <= (hope + 10))
            yaw = hope * 0.5 + 0.5 * yaw;
            else if(yaw >= (hope - 20) && yaw < (hope - 10))
               yaw = (hope -5) - ((hope - 10) - yaw) * 1.5;

            else if(yaw > (hope + 10) && yaw < (hope + 20))
               yaw = (hope + 5) + (yaw - (hope + 10)) * 1.5;


        if(yaw > 180)
            yaw -= 360;

        yaw = yaw/TODEG;

        float cp = cosf(pitch);
        float sp = sinf(pitch);
        float sr = sinf(roll);
        float cr = cosf(roll);

        float sy = sinf(yaw);
        float cy = cosf(yaw);


        // 1 yaw       2 roll   3 pitch
#if 0
        mat33_t_R_yzw[0][0] = cy * cr;
        mat33_t_R_yzw[0][1] = -(cy * sr * sp - cp * sy);

        mat33_t_R_yzw[0][2] = sy * sp + cy * cp * sy;

        mat33_t_R_yzw[1][0] = -(cr * sy);
        mat33_t_R_yzw[1][1] = cy * cp + sy * sr * sp;

        mat33_t_R_yzw[1][2] = -(cp * sy * sr - cy * sp);

        mat33_t_R_yzw[2][0] = -sr;
        mat33_t_R_yzw[2][1] = -(cr * sp);

        mat33_t_R_yzw[2][2] = cr * cp;
#endif
        mat33_t_R_yzw[0][0] = cy * cr;

        mat33_t_R_yzw[0][1] = (cy * sr * sp + cp * sy);
        mat33_t_R_yzw[0][2] = sy * sp - cy * cp * sr;

        mat33_t_R_yzw[1][0] = -(cr * sy);

        mat33_t_R_yzw[1][1] = -(sy * sr * sp -cy * cp);
        mat33_t_R_yzw[1][2] = cp*sr*sy + sp*cy;

        mat33_t_R_yzw[2][0] = sr;

        mat33_t_R_yzw[2][1] = -(cr * sp);
        mat33_t_R_yzw[2][2] = cr * cp;


        const float Hx = mat33_t_R_yzw[0][0];
        const float My = mat33_t_R_yzw[1][1];
        const float Az = mat33_t_R_yzw[2][2];

        quat[0] = sqrtf(clamp(Hx - My - Az + 1) * 0.25f);
        quat[1] = sqrtf(clamp(-Hx + My - Az + 1) * 0.25f);
        quat[2] = sqrtf(clamp(-Hx - My + Az + 1) * 0.25f);
        quat[3] = sqrtf(clamp(Hx + My + Az + 1) * 0.25f);

        quat[0] = copysignf(quat[0], mat33_t_R_yzw[2][1] - mat33_t_R_yzw[1][2]);
        quat[1] = copysignf(quat[1], mat33_t_R_yzw[0][2] - mat33_t_R_yzw[2][0]);
        quat[2] = copysignf(quat[2], mat33_t_R_yzw[1][0] - mat33_t_R_yzw[0][1]);

    }
#endif
}



float fusion_nomag_q0 = 1.0f;
float fusion_nomag_q1 = 0.0f;
float fusion_nomag_q2 = 0.0f;
float fusion_nomag_q3 = 0.0f;

float fusion_nomag_kp = 2.0f;
float fusion_nomag_ki = 0.1f;
float fusion_nomag_Int_max = 0.05f;
float fusion_nomag_exInt = 0;
float fusion_nomag_eyInt = 0;
float fusion_nomag_ezInt = 0;

float fusion_nomag_rot_mat[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};

float fusion_nomag_quaternion[4] = {1, 0, 0, 0};

float fusion_nomag_q_init[4] = {0, 0, 0, 0};

void qst_fusion_nomag_rotation_matrix(void)
{
    float q2q2 = fusion_nomag_q2 * fusion_nomag_q2;
    float q2q3 = fusion_nomag_q2 * fusion_nomag_q3;
    float q1q1 = fusion_nomag_q1 * fusion_nomag_q1;
    float q1q2 = fusion_nomag_q1 * fusion_nomag_q2;
    float q1q3 = fusion_nomag_q1 * fusion_nomag_q3;
    float q0q1 = fusion_nomag_q0 * fusion_nomag_q1;
    float q0q2 = fusion_nomag_q0 * fusion_nomag_q2;
    float q0q3 = fusion_nomag_q0 * fusion_nomag_q3;
    float q3q3 = fusion_nomag_q3 * fusion_nomag_q3;
  
    fusion_nomag_rot_mat[0][0] = 1 - 2 * (q2q2 + q3q3);
    fusion_nomag_rot_mat[0][1] = 2 * (q1q2 - q0q3);
    fusion_nomag_rot_mat[0][2] = 2 * (q1q3 + q0q2);
  
    fusion_nomag_rot_mat[1][0] = 2 * (q1q2 + q0q3);
    fusion_nomag_rot_mat[1][1] = 1 - 2 * (q1q1 + q3q3);
    fusion_nomag_rot_mat[1][2] = 2 * (q2q3 - q0q1);
 
    fusion_nomag_rot_mat[2][0] = 2 * (q1q3 - q0q2);
    fusion_nomag_rot_mat[2][1] = 2 * (q2q3 + q0q1);
    fusion_nomag_rot_mat[2][2] = 1-2 * (q1q1 + q2q2);
}

//float fusion_nomag_init_pitch = 0;
//float fusion_nomag_init_roll = 0;
//float fusion_nomag_init_yaw = 0;
unsigned char qst_fusion_nomag_init(float accel_in[3], float mag_in[3]) 
{
    float accel_data[3] = {0, 0, 0};
    float mat33_t_R[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    accel_data[0] = accel_in[0];
    accel_data[1] = accel_in[1];
    accel_data[2] = accel_in[2];
    
    float normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);
    accel_data[0] = accel_data[0] / normalize;
    accel_data[1] = accel_data[1] / normalize;
    accel_data[2] = accel_data[2] / normalize;

    float pitch = -atan2f(accel_data[1], accel_data[2]);
#ifdef IMUALGO_LOG
    float fusion_nomag_init_pitch = pitch * TODEG;////ž©ÑöœÇ
#endif

    normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);

    float roll = asinf((accel_data[0] / normalize));//ºá¹öœÇ
#ifdef IMUALGO_LOG
    float fusion_nomag_init_roll = roll * TODEG;//ºá¹öœÇ
#endif

    float cp = cosf(pitch);   //roll=0,  pitch=0;      //1
    float sp = sinf(pitch);                                 //0
    float sr = sinf(roll);                                     //0
    float cr = cosf(roll);                                   //  1

    float yaw = 0; 

#ifdef IMUALGO_LOG
    float fusion_nomag_init_yaw = yaw * TODEG;
    if(fusion_nomag_init_yaw < 0.0f)
    {
        fusion_nomag_init_yaw += 360.0f;
    }
#endif
#ifdef IMUALGO_LOG
    D("%s,inited:%d; %d; %d\r\n", __func__,(int32_t)fusion_nomag_init_pitch, (int32_t)fusion_nomag_init_roll, (int32_t)fusion_nomag_init_yaw);
#endif
    float sy = sinf(yaw);
    float cy = cosf(yaw);

    // 1 yaw       2 roll   3 pitch
    mat33_t_R[0][0] = cy * cr;
    mat33_t_R[0][1] = -(cy * sr * sp - cp * sy);
    mat33_t_R[0][2] = sy * sp + cy * cp * sy;

    mat33_t_R[1][0] = -(cr * sy);
    mat33_t_R[1][1] = cy * cp + sy * sr * sp;
    mat33_t_R[1][2] = -(cp * sy * sr - cy * sp);

    mat33_t_R[2][0] = -sr;
    mat33_t_R[2][1] = -(cr * sp);
    mat33_t_R[2][2] = cr * cp;

    fusion_nomag_q_init[0] = sqrtf(clamp( mat33_t_R[0][0] - mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nomag_q_init[1] = sqrtf(clamp(-mat33_t_R[0][0] + mat33_t_R[1][1] - mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nomag_q_init[2] = sqrtf(clamp(-mat33_t_R[0][0] - mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);
    fusion_nomag_q_init[3] = sqrtf(clamp( mat33_t_R[0][0] + mat33_t_R[1][1] + mat33_t_R[2][2] + 1) * 0.25f);

    fusion_nomag_q_init[0] = copysignf(fusion_nomag_q_init[0], mat33_t_R[2][1] - mat33_t_R[1][2]);
    fusion_nomag_q_init[1] = copysignf(fusion_nomag_q_init[1], mat33_t_R[0][2] - mat33_t_R[2][0]);
    fusion_nomag_q_init[2] = copysignf(fusion_nomag_q_init[2], mat33_t_R[1][0] - mat33_t_R[0][1]);

    float q_length =  sqrtf(fusion_nomag_q_init[0] * fusion_nomag_q_init[0] + fusion_nomag_q_init[1] * fusion_nomag_q_init[1] + fusion_nomag_q_init[2] * fusion_nomag_q_init[2] + fusion_nomag_q_init[3] * fusion_nomag_q_init[3]);//¹éÒ»»¯
    fusion_nomag_q_init[0] = fusion_nomag_q_init[0] / q_length;
    fusion_nomag_q_init[1] = fusion_nomag_q_init[1] / q_length;
    fusion_nomag_q_init[2] = fusion_nomag_q_init[2] / q_length;
    fusion_nomag_q_init[3] = fusion_nomag_q_init[3] / q_length;

    if(/*isfinite(fusion_nomag_q_init[0]) && isfinite(fusion_nomag_q_init[1]) &&
        isfinite(fusion_nomag_q_init[2]) && isfinite(fusion_nomag_q_init[3]) &&*/
        q_length > 0.95f && q_length < 1.05f) 
    {
        fusion_nomag_inited = 1;
    } 
    else
    {
        fusion_nomag_inited = 0;
    }

    fusion_nomag_q0 = fusion_nomag_q_init[3];
    fusion_nomag_q1 = fusion_nomag_q_init[0];
    fusion_nomag_q2 = fusion_nomag_q_init[1];
    fusion_nomag_q3 = fusion_nomag_q_init[2];

    qst_fusion_nomag_rotation_matrix();

    return fusion_nomag_inited;
}





void qst_fusion_nomag_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart)
{
    float ex = 0.0f;
    float ey = 0.0f;
    float ez = 0.0f;

    float integral_dt = *fusion_dt;
    float halfT = 0.5f * integral_dt;

    float accel_tmp[3] = {0.0f, 0.0f, 0.0f};
    float gyro_tmp[3] = {0.0f, 0.0f, 0.0f};
    float mag_tmp[3] = {0.0f, 0.0f, 0.0f};

    accel_tmp[0] = fusion_accel[0];
    accel_tmp[1] = fusion_accel[1];
    accel_tmp[2] = fusion_accel[2];

    gyro_tmp[0] = fusion_gyro[0];
    gyro_tmp[1] = fusion_gyro[1];
    gyro_tmp[2] = fusion_gyro[2];

    if(integral_dt > 0.5f)
    {
        fusion_nomag_inited = 0;
    }
    else
    {
        if(integral_dt < 0.0f || integral_dt > 0.04f)
        {
            integral_dt = 0.005f;
            halfT = 0.5f * integral_dt;
        }
    }

    if(restart&&*restart) 
    {
        fusion_nomag_inited = 0;
    }

    if(!fusion_nomag_inited) 
    {
        qst_fusion_nomag_init(accel_tmp, mag_tmp);
        return;
    }

    float recip_norm = sqrtf(accel_tmp[0] * accel_tmp[0] + accel_tmp[1] * accel_tmp[1] + accel_tmp[2] * accel_tmp[2]);
    if(recip_norm > GRAVITY_MSS * 0.9f && recip_norm <  GRAVITY_MSS * 1.1f)
    {
        accel_tmp[0] = accel_tmp[0] / recip_norm;
        accel_tmp[1] = accel_tmp[1] / recip_norm;
        accel_tmp[2] = accel_tmp[2] / recip_norm;

        ex = (accel_tmp[1] * fusion_nomag_rot_mat[2][2] - accel_tmp[2] * fusion_nomag_rot_mat[2][1]) * fusion_nomag_kp;
        ey = (accel_tmp[2] * fusion_nomag_rot_mat[2][0] - accel_tmp[0] * fusion_nomag_rot_mat[2][2]) * fusion_nomag_kp;
        ez = (accel_tmp[0] * fusion_nomag_rot_mat[2][1] - accel_tmp[1] * fusion_nomag_rot_mat[2][0]) * fusion_nomag_kp;
    }

    float spinRate = sqrtf(gyro_tmp[0] * gyro_tmp[0] + gyro_tmp[1] * gyro_tmp[1] + gyro_tmp[2] * gyro_tmp[2]);
    if(spinRate < 0.35f) //20
    {
        fusion_nomag_exInt += ex * fusion_nomag_ki * integral_dt;
        fusion_nomag_eyInt += ey * fusion_nomag_ki * integral_dt;
        fusion_nomag_ezInt += ez * fusion_nomag_ki * integral_dt;
        fusion_nomag_exInt = constrain_float(fusion_nomag_exInt, -fusion_nomag_Int_max, fusion_nomag_Int_max);
        fusion_nomag_eyInt = constrain_float(fusion_nomag_eyInt, -fusion_nomag_Int_max, fusion_nomag_Int_max);
        fusion_nomag_ezInt = constrain_float(fusion_nomag_ezInt, -fusion_nomag_Int_max, fusion_nomag_Int_max);
    }
    else
    {
        fusion_nomag_exInt = 0.0f;
        fusion_nomag_eyInt = 0.0f;
        fusion_nomag_ezInt = 0.0f;
    }

    gyro_tmp[0] = gyro_tmp[0] + ex + fusion_nomag_exInt;
    gyro_tmp[1] = gyro_tmp[1] + ey + fusion_nomag_eyInt;
    gyro_tmp[2] = gyro_tmp[2] + ez + fusion_nomag_ezInt;

    float qw = fusion_nomag_q0;
    float qx = fusion_nomag_q1;
    float qy = fusion_nomag_q2;
    float qz = fusion_nomag_q3;

    fusion_nomag_q0 += (-qx * gyro_tmp[0] - qy * gyro_tmp[1] - qz * gyro_tmp[2]) * halfT;
    fusion_nomag_q1 += (+qw * gyro_tmp[0] + qy * gyro_tmp[2] - qz * gyro_tmp[1]) * halfT;
    fusion_nomag_q2 += (+qw * gyro_tmp[1] - qx * gyro_tmp[2] + qz * gyro_tmp[0]) * halfT;
    fusion_nomag_q3 += (+qw * gyro_tmp[2] + qx * gyro_tmp[1] - qy * gyro_tmp[0]) * halfT;

    recip_norm = sqrtf(fusion_nomag_q0 * fusion_nomag_q0 + fusion_nomag_q1 * fusion_nomag_q1 + fusion_nomag_q2 * fusion_nomag_q2 + fusion_nomag_q3 * fusion_nomag_q3);
    fusion_nomag_q0 = fusion_nomag_q0 / recip_norm;
    fusion_nomag_q1 = fusion_nomag_q1 / recip_norm;
    fusion_nomag_q2 = fusion_nomag_q2 / recip_norm;
    fusion_nomag_q3 = fusion_nomag_q3 / recip_norm;

    qst_fusion_nomag_rotation_matrix();
}

void qst_fusion_nomag_angle(float *rpy)
{
    float roll  = asinf(fusion_nomag_rot_mat[2][0]) * TODEG;
    float pitch = -atan2f(fusion_nomag_rot_mat[2][1], fusion_nomag_rot_mat[2][2]) * TODEG; 
    float yaw = -atan2f(fusion_nomag_rot_mat[1][0], fusion_nomag_rot_mat[0][0]) * TODEG; 

    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}

void qst_fusion_nomag_get_quaternion(float quat[4])
{
    const float Hx = fusion_nomag_rot_mat[0][0];
    const float My = fusion_nomag_rot_mat[1][1];
    const float Az = fusion_nomag_rot_mat[2][2];
    quat[0] = sqrtf( clamp( Hx - My - Az + 1) * 0.25f );
    quat[1] = sqrtf( clamp(-Hx + My - Az + 1) * 0.25f );
    quat[2] = sqrtf( clamp(-Hx - My + Az + 1) * 0.25f );
    quat[3] = sqrtf( clamp( Hx + My + Az + 1) * 0.25f );
    quat[0] = copysignf(quat[0], fusion_nomag_rot_mat[2][1] - fusion_nomag_rot_mat[1][2]);
    quat[1] = copysignf(quat[1], fusion_nomag_rot_mat[0][2] - fusion_nomag_rot_mat[2][0]);
    quat[2] = copysignf(quat[2], fusion_nomag_rot_mat[1][0] - fusion_nomag_rot_mat[0][1]);
}


float fusion_nogyro_q0 = 1.0f;
float fusion_nogyro_q1 = 0.0f;
float fusion_nogyro_q2 = 0.0f;
float fusion_nogyro_q3 = 0.0f;

float fusion_nogyro_mag_kp = 2.0f;

float fusion_nogyro_kp = 2.0f;
float fusion_nogyro_ki = 0.1f;
float fusion_nogyro_Int_max = 0.05f;
float fusion_nogyro_exInt = 0;
float fusion_nogyro_eyInt = 0;
float fusion_nogyro_ezInt = 0;

float fusion_nogyro_rot_mat[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};

float fusion_nogyro_quaternion[4]= {1, 0, 0, 0};

/****************** žùŸÝ³õÊŒ»¯Å·À­œÇ³õÊŒ»¯ËÄÔªÊý *****************************/
unsigned char fusion_nogyro_inited = 0;
float fusion_nogyro_q_init[4] = {0, 0, 0, 0};


void qst_fusion_nogyro_rotation_matrix(void)
{
    float q2q2 = fusion_nogyro_q2 * fusion_nogyro_q2;
    float q2q3 = fusion_nogyro_q2 * fusion_nogyro_q3;
    float q1q1 = fusion_nogyro_q1 * fusion_nogyro_q1;
    float q1q2 = fusion_nogyro_q1 * fusion_nogyro_q2;
    float q1q3 = fusion_nogyro_q1 * fusion_nogyro_q3;
    float q0q1 = fusion_nogyro_q0 * fusion_nogyro_q1;
    float q0q2 = fusion_nogyro_q0 * fusion_nogyro_q2;
    float q0q3 = fusion_nogyro_q0 * fusion_nogyro_q3;
    float q3q3 = fusion_nogyro_q3 * fusion_nogyro_q3;

    fusion_nogyro_rot_mat[0][0] = 1 - 2 * (q2q2 + q3q3);
    fusion_nogyro_rot_mat[0][1] = 2 * (q1q2 - q0q3);
    fusion_nogyro_rot_mat[0][2] = 2 * (q1q3 + q0q2);

    fusion_nogyro_rot_mat[1][0] = 2 * (q1q2 + q0q3);
    fusion_nogyro_rot_mat[1][1] = 1 - 2 * (q1q1 + q3q3);
    fusion_nogyro_rot_mat[1][2] = 2 * (q2q3 - q0q1);

    fusion_nogyro_rot_mat[2][0] = 2 * (q1q3 - q0q2);
    fusion_nogyro_rot_mat[2][1] = 2 * (q2q3 + q0q1);
    fusion_nogyro_rot_mat[2][2] = 1-2 * (q1q1 + q2q2);
}



#if 0//def USING_ACC_LOCK
static float old_yaw_no_gyro = 0;
#endif
void qst_fusion_nogyro_update(float fusion_accel[3], float fusion_gyro[3], float fusion_mag[3], float *fusion_dt, unsigned char *restart)
{
    float accel_data[3] = {0.0f, 0.0f, 0.0f};
    float mag_data[3] = {0.0f, 0.0f, 0.0f};
    float mag_data_temp[3] = {0, 0, 0};
    float sinyaw = 0;
    float cosyaw = 0;
    float fusion_rot_mat1[3][3] = {{1.0f, 0.f, 0.f}, {0.0f, 1.0f, 0.f}, {0.0f, 0.f, 1.0f}};
    accel_data[0] = fusion_accel[0];
    accel_data[1] = fusion_accel[1];
    accel_data[2] = fusion_accel[2];

    float normalize = sqrtf(accel_data[0] * accel_data[0] + accel_data[1] * accel_data[1] + accel_data[2] * accel_data[2]);
    if(normalize > GRAVITY_MSS * 0.8f && normalize <  GRAVITY_MSS * 1.2f){
        accel_data[0] = accel_data[0] / normalize;
        accel_data[1] = accel_data[1] / normalize;
        accel_data[2] = accel_data[2] / normalize;

        fusion_rot_mat1[2][0] = accel_data[0];
        fusion_rot_mat1[2][1] = accel_data[1]; 
        fusion_rot_mat1[2][2] = accel_data[2];

        if(fabs(fusion_rot_mat1[2][0]) > 0.5) 
        {  
            fusion_rot_mat1[1][0] = fusion_rot_mat1[2][1];  
            fusion_rot_mat1[1][1] = -fusion_rot_mat1[2][0];  
            fusion_rot_mat1[1][2] = 0; 
        }else{  
            fusion_rot_mat1[1][0] = 0;  
            fusion_rot_mat1[1][1] = fusion_rot_mat1[2][2]; 
            fusion_rot_mat1[1][2] = -fusion_rot_mat1[2][1];  
        }

        //归一化
        normalize = sqrtf(fusion_rot_mat1[1][0] * fusion_rot_mat1[1][0] + fusion_rot_mat1[1][1] * fusion_rot_mat1[1][1]+ fusion_rot_mat1[1][2] * fusion_rot_mat1[1][2]); 
        fusion_rot_mat1[1][0] = fusion_rot_mat1[1][0] / normalize; 
        fusion_rot_mat1[1][1] = fusion_rot_mat1[1][1] / normalize; 
        fusion_rot_mat1[1][2] = fusion_rot_mat1[1][2] / normalize;  

        //做叉积求C0(第一行) 
        fusion_rot_mat1[0][0] = fusion_rot_mat1[1][1] * fusion_rot_mat1[2][2] - fusion_rot_mat1[2][1] * fusion_rot_mat1[1][2]; 
        fusion_rot_mat1[0][1] = -(fusion_rot_mat1[1][0] * fusion_rot_mat1[2][2] - fusion_rot_mat1[2][0] * fusion_rot_mat1[1][2]); 
        fusion_rot_mat1[0][2] = fusion_rot_mat1[1][0] * fusion_rot_mat1[2][1] - fusion_rot_mat1[2][0] * fusion_rot_mat1[1][1];
        //构造水平姿态对准结束
        //计算磁力计的方位对准开始
        mag_data[0] = fusion_mag[0];
        mag_data[1] = fusion_mag[1];
        mag_data[2] = fusion_mag[2];

        normalize = sqrtf(mag_data[0] * mag_data[0] + mag_data[1] * mag_data[1] + mag_data[2] * mag_data[2]);
        if(normalize > 0){
            mag_data[0] = mag_data[0] / normalize;
            mag_data[1] = mag_data[1] / normalize;
            mag_data[2] = mag_data[2] / normalize;
            //转置
            mag_data_temp[0] = fusion_rot_mat1[0][0] * mag_data[0] + fusion_rot_mat1[0][1] * mag_data[1] + fusion_rot_mat1[0][2] * mag_data[2];
            mag_data_temp[1] = fusion_rot_mat1[1][0] * mag_data[0] + fusion_rot_mat1[1][1] * mag_data[1] + fusion_rot_mat1[1][2] * mag_data[2];
            mag_data_temp[2] = fusion_rot_mat1[2][0] * mag_data[0] + fusion_rot_mat1[2][1] * mag_data[1] + fusion_rot_mat1[2][2] * mag_data[2];
        }
            
        sinyaw = mag_data_temp[0] / sqrtf(mag_data_temp[0] * mag_data_temp[0] + mag_data_temp[1] * mag_data_temp[1]);    
        cosyaw = mag_data_temp[1] / sqrtf(mag_data_temp[0] * mag_data_temp[0] + mag_data_temp[1] * mag_data_temp[1]);

        if(sinyaw <= -1){
            sinyaw = -1;
        }else if(sinyaw >= 1){
            sinyaw = 1;
        }    
        if(cosyaw <= -1){
            cosyaw = -1;
        }else if(cosyaw >= 1){
            cosyaw = 1;
        }
        //计算磁力计的方位对准结束

        fusion_nogyro_rot_mat[0][0] = cosyaw * fusion_rot_mat1[0][0] - sinyaw * fusion_rot_mat1[1][0];
        fusion_nogyro_rot_mat[0][1] = cosyaw * fusion_rot_mat1[0][1] - sinyaw * fusion_rot_mat1[1][1];
        fusion_nogyro_rot_mat[0][2] = cosyaw * fusion_rot_mat1[0][2] - sinyaw * fusion_rot_mat1[1][2];

        fusion_nogyro_rot_mat[1][0] = sinyaw * fusion_rot_mat1[0][0] + cosyaw * fusion_rot_mat1[1][0];
        fusion_nogyro_rot_mat[1][1] = sinyaw * fusion_rot_mat1[0][1] + cosyaw * fusion_rot_mat1[1][1];
        fusion_nogyro_rot_mat[1][2] = sinyaw * fusion_rot_mat1[0][2] + cosyaw * fusion_rot_mat1[1][2];

        fusion_nogyro_rot_mat[2][0] = fusion_rot_mat1[2][0];
        fusion_nogyro_rot_mat[2][1] = fusion_rot_mat1[2][1];
        fusion_nogyro_rot_mat[2][2] = fusion_rot_mat1[2][2];
#if 0
        if(fusion_nogyro_rot_mat[0][0] >= fusion_nogyro_rot_mat[1][1] + fusion_nogyro_rot_mat[2][2]){
            fusion_nogyro_q1 = 0.5 * sqrtf(1 + fusion_nogyro_rot_mat[0][0] - fusion_nogyro_rot_mat[1][1] - fusion_nogyro_rot_mat[2][2]);
            fusion_nogyro_q0 = (fusion_nogyro_rot_mat[2][1] - fusion_nogyro_rot_mat[1][2]) / (4 * fusion_nogyro_q1);
            fusion_nogyro_q2 = (fusion_nogyro_rot_mat[0][1] + fusion_nogyro_rot_mat[1][0]) / (4 * fusion_nogyro_q1);
            fusion_nogyro_q3 = (fusion_nogyro_rot_mat[0][2] + fusion_nogyro_rot_mat[2][0]) / (4 * fusion_nogyro_q1);
        }else if(fusion_nogyro_rot_mat[1][1] >= fusion_nogyro_rot_mat[0][0] + fusion_nogyro_rot_mat[2][2]){
            fusion_nogyro_q2 = 0.5 * sqrtf(1 - fusion_nogyro_rot_mat[0][0] + fusion_nogyro_rot_mat[1][1] - fusion_nogyro_rot_mat[2][2]);
            fusion_nogyro_q0 = (fusion_nogyro_rot_mat[0][2] - fusion_nogyro_rot_mat[2][0]) / (4 * fusion_nogyro_q2);
            fusion_nogyro_q1 = (fusion_nogyro_rot_mat[0][1] + fusion_nogyro_rot_mat[1][0]) / (4 * fusion_nogyro_q2);
            fusion_nogyro_q3 = (fusion_nogyro_rot_mat[1][2] + fusion_nogyro_rot_mat[2][1]) / (4 * fusion_nogyro_q2);
        }else if(fusion_nogyro_rot_mat[2][2] >= fusion_nogyro_rot_mat[0][0] + fusion_nogyro_rot_mat[1][1]){
            fusion_nogyro_q3 = 0.5 * sqrtf(1 - fusion_nogyro_rot_mat[0][0] - fusion_nogyro_rot_mat[1][1] + fusion_nogyro_rot_mat[2][2]);
            fusion_nogyro_q0 = (fusion_nogyro_rot_mat[1][0] - fusion_nogyro_rot_mat[0][1]) / (4 * fusion_nogyro_q3);
            fusion_nogyro_q1 = (fusion_nogyro_rot_mat[0][2] + fusion_nogyro_rot_mat[2][0]) / (4 * fusion_nogyro_q3);
            fusion_nogyro_q2 = (fusion_nogyro_rot_mat[1][2] + fusion_nogyro_rot_mat[2][1]) / (4 * fusion_nogyro_q3);
        }else{
            fusion_nogyro_q0 = 0.5 * sqrtf(1 + fusion_nogyro_rot_mat[0][0] + fusion_nogyro_rot_mat[1][1] + fusion_nogyro_rot_mat[2][2]);
            fusion_nogyro_q1 = (fusion_nogyro_rot_mat[2][1] - fusion_nogyro_rot_mat[1][2]) / (4 * fusion_nogyro_q0);
            fusion_nogyro_q2 = (fusion_nogyro_rot_mat[0][2] - fusion_nogyro_rot_mat[2][0]) / (4 * fusion_nogyro_q0);
            fusion_nogyro_q3 = (fusion_nogyro_rot_mat[1][0] - fusion_nogyro_rot_mat[0][1]) / (4 * fusion_nogyro_q0);
        }
#endif
    }
}


void qst_fusion_nogyro_angle(float *rpy)
{
    float roll  = asinf(fusion_nogyro_rot_mat[2][0]) * TODEG;
    float pitch = -atan2f(fusion_nogyro_rot_mat[2][1], fusion_nogyro_rot_mat[2][2]) * TODEG; 
    float yaw = -atan2f(fusion_nogyro_rot_mat[1][0], fusion_nogyro_rot_mat[0][0]) * TODEG; 

    if(yaw < 0.0f)
    {
        yaw += 360.0f;
    }

    rpy[1] = pitch;
    rpy[2] = roll;
    rpy[0] = yaw;
}

void qst_fusion_nogyro_get_quaternion(float quat[4])
{
#ifdef QST_SUPPORT_YAW
    float mat33_t_R_yzw[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
#endif
    const float Hx = fusion_nogyro_rot_mat[0][0];
    const float My = fusion_nogyro_rot_mat[1][1];
    const float Az = fusion_nogyro_rot_mat[2][2];
    quat[0] = sqrtf( clamp( Hx - My - Az + 1) * 0.25f );
    quat[1] = sqrtf( clamp(-Hx + My - Az + 1) * 0.25f );
    quat[2] = sqrtf( clamp(-Hx - My + Az + 1) * 0.25f );
    quat[3] = sqrtf( clamp( Hx + My + Az + 1) * 0.25f );
    quat[0] = copysignf(quat[0], fusion_nogyro_rot_mat[2][1] - fusion_nogyro_rot_mat[1][2]);
    quat[1] = copysignf(quat[1], fusion_nogyro_rot_mat[0][2] - fusion_nogyro_rot_mat[2][0]);
    quat[2] = copysignf(quat[2], fusion_nogyro_rot_mat[1][0] - fusion_nogyro_rot_mat[0][1]);
#if defined(QST_SUPPORT_YAW)
    {
        float quat_t[4];

        quat_t[0] = quat[3];
        quat_t[1] = quat[0];
        quat_t[2] = quat[1];
        quat_t[3] = quat[2];

        float roll = asinf(2 * (quat_t[1] * quat_t[3] - quat_t[0] * quat_t[2]));
        float pitch = -atan2f(2 * (quat_t[2] * quat_t[3] + quat_t[0] * quat_t[1]), 1 - 2 * (quat_t[1] * quat_t[1] + quat_t[2] * quat_t[2])); 
        //float yaw = -atan2f(2 * (quat_t[1] * quat_t[2] + quat_t[0] * quat_t[3]), 1 - 2 * (quat_t[2] * quat_t[2] + quat_t[3] * quat_t[3]));
        float yaw = atan2f(-2 * (quat_t[1] * quat_t[2] + quat_t[0] * quat_t[3]),  1 - 2 * (quat_t[2] * quat_t[2] + quat_t[3] * quat_t[3]));
        yaw = yaw*TODEG;

        if (yaw  < 0)
            yaw += 360;

        int hope =0;
        hope = (int)((yaw / 45) + 0.5) * 45;

        if(yaw >= (hope - 10) && yaw <= (hope + 10))
            yaw = hope * 0.5 + 0.5 * yaw;
            else if(yaw >= (hope - 20) && yaw < (hope - 10))
               yaw = (hope -5) - ((hope - 10) - yaw) * 1.5;

            else if(yaw > (hope + 10) && yaw < (hope + 20))
               yaw = (hope + 5) + (yaw - (hope + 10)) * 1.5;


        if(yaw > 180)
            yaw -= 360;

        yaw = yaw/TODEG;

        float cp = cosf(pitch);
        float sp = sinf(pitch);
        float sr = sinf(roll);
        float cr = cosf(roll);

        float sy = sinf(yaw);
        float cy = cosf(yaw);


        //1 yaw       2 roll   3 pitch
#if 0
        mat33_t_R_yzw[0][0] = cy * cr;
        mat33_t_R_yzw[0][1] = -(cy * sr * sp - cp * sy);

        mat33_t_R_yzw[0][2] = sy * sp + cy * cp * sy;

        mat33_t_R_yzw[1][0] = -(cr * sy);
        mat33_t_R_yzw[1][1] = cy * cp + sy * sr * sp;

        mat33_t_R_yzw[1][2] = -(cp * sy * sr - cy * sp);

        mat33_t_R_yzw[2][0] = -sr;
        mat33_t_R_yzw[2][1] = -(cr * sp);

        mat33_t_R_yzw[2][2] = cr * cp;
#endif
        mat33_t_R_yzw[0][0] = cy * cr;

        mat33_t_R_yzw[0][1] = (cy * sr * sp + cp * sy);
        mat33_t_R_yzw[0][2] = sy * sp - cy * cp * sr;

        mat33_t_R_yzw[1][0] = -(cr * sy);

        mat33_t_R_yzw[1][1] = -(sy * sr * sp -cy * cp);
        mat33_t_R_yzw[1][2] = cp*sr*sy + sp*cy;

        mat33_t_R_yzw[2][0] = sr;

        mat33_t_R_yzw[2][1] = -(cr * sp);
        mat33_t_R_yzw[2][2] = cr * cp;


        const float hx = mat33_t_R_yzw[0][0];
        const float my = mat33_t_R_yzw[1][1];
        const float az = mat33_t_R_yzw[2][2];

        quat[0] = sqrtf(clamp(hx - my - az + 1) * 0.25f);
        quat[1] = sqrtf(clamp(-hx + my - az + 1) * 0.25f);
        quat[2] = sqrtf(clamp(-hx - my + az + 1) * 0.25f);
        quat[3] = sqrtf(clamp(hx + my + az + 1) * 0.25f);

        quat[0] = copysignf(quat[0], mat33_t_R_yzw[2][1] - mat33_t_R_yzw[1][2]);
        quat[1] = copysignf(quat[1], mat33_t_R_yzw[0][2] - mat33_t_R_yzw[2][0]);
        quat[2] = copysignf(quat[2], mat33_t_R_yzw[1][0] - mat33_t_R_yzw[0][1]);

    }
#endif
}
void qst_fusion_gravity(float gra_data[3],int mode)
{
	if(mode == 1)
	{
        gra_data[0] = fusion_9axis_rot_mat[2][0] * GRAVITY_MSS;
        gra_data[1] = fusion_9axis_rot_mat[2][1] * GRAVITY_MSS;
        gra_data[2] = fusion_9axis_rot_mat[2][2] * GRAVITY_MSS;
	}
    else if(mode == 2)
	{
        gra_data[0] = fusion_nomag_rot_mat[2][0] * GRAVITY_MSS;
        gra_data[1] = fusion_nomag_rot_mat[2][1] * GRAVITY_MSS;
        gra_data[2] = fusion_nomag_rot_mat[2][2] * GRAVITY_MSS;
    }
	else
	{
        gra_data[0] = fusion_nogyro_rot_mat[2][0] * GRAVITY_MSS;
        gra_data[1] = fusion_nogyro_rot_mat[2][1] * GRAVITY_MSS;
        gra_data[2] = fusion_nogyro_rot_mat[2][2] * GRAVITY_MSS;
    }

}
#if 0
void qst_fusion_get_matrix(float matrix[9],int mode)
{
    float *matrix_ptr = NULL;
    
    if(mode == 0)
        matrix_ptr = (float *)fusion_9axis_rot_mat;
    else if(mode == 1)
        matrix_ptr = (float *)fusion_nomag_rot_mat;
    else if(mode == 2)
        matrix_ptr = (float *)fusion_nogyro_rot_mat;
    else
        matrix_ptr = NULL;

    if(matrix_ptr)
    {
        matrix[0] = matrix_ptr[0];
        matrix[1] = matrix_ptr[1];
        matrix[2] = matrix_ptr[2];
        matrix[3] = matrix_ptr[3];
        matrix[4] = matrix_ptr[4];
        matrix[5] = matrix_ptr[5];
        matrix[6] = matrix_ptr[6];
        matrix[7] = matrix_ptr[7];
        matrix[8] = matrix_ptr[8];
    }
}

void qst_fusion_get_quat(float quat[4],int mode)
{
    if(mode == 0)    // 9axis
        qst_fusion_9axis_euler_to_quaternion(quat);
    else if(mode == 1)    //    a+g
        qst_fusion_nomag_euler_to_quaternion(quat);
    else if(mode == 2)    // a+m
        qst_fusion_nogyro_euler_to_quaternion(quat);

#if defined(QST_SUPPORT_YAW)
    if((mode==0)||(mode==2))
    {
        float quat_t[4];
        
        quat_t[0] = quat[3];
        quat_t[1] = quat[0];
        quat_t[2] = quat[1];
        quat_t[3] = quat[2];

        float roll = asinf(2 * (quat_t[1] * quat_t[3] - quat_t[0] * quat_t[2]));
        float pitch = -atan2f(2 * (quat_t[2] * quat_t[3] + quat_t[0] * quat_t[1]), 1 - 2 * (quat_t[1] * quat_t[1] + quat_t[2] * quat_t[2])); 
        //float yaw = -atan2f(2 * (quat_t[1] * quat_t[2] + quat_t[0] * quat_t[3]), 1 - 2 * (quat_t[2] * quat_t[2] + quat_t[3] * quat_t[3]));
        float yaw = atan2f(-2 * (quat_t[1] * quat_t[2] + quat_t[0] * quat_t[3]),  1 - 2 * (quat_t[2] * quat_t[2] + quat_t[3] * quat_t[3]));
        yaw = yaw*TODEG;
        if (yaw  < 0)
            yaw += 360;

        int hope =0;
        hope = (int)((yaw / 45) + 0.5) * 45;

        if(yaw >= (hope - 10) && yaw <= (hope + 10))
            yaw = hope * 0.5 + 0.5 * yaw;
            else if(yaw >= (hope - 20) && yaw < (hope - 10))
               yaw = (hope -5) - ((hope - 10) - yaw) * 1.5;
            else if(yaw > (hope + 10) && yaw < (hope + 20))
               yaw = (hope + 5) + (yaw - (hope + 10)) * 1.5;

        if(yaw > 180)
            yaw -= 360;

        yaw = yaw/TODEG;
        float cp = cosf(pitch);
        float sp = sinf(pitch);
        float sr = sinf(roll);
        float cr = cosf(roll);
        float sy = sinf(yaw);
        float cy = cosf(yaw);

        //1 yaw       2 roll   3 pitch
#if 0
        mat33_t_R_yzw[0][0] = cy * cr;
        mat33_t_R_yzw[0][1] = -(cy * sr * sp - cp * sy);
        mat33_t_R_yzw[0][2] = sy * sp + cy * cp * sy;

        mat33_t_R_yzw[1][0] = -(cr * sy);
        mat33_t_R_yzw[1][1] = cy * cp + sy * sr * sp;
        mat33_t_R_yzw[1][2] = -(cp * sy * sr - cy * sp);

        mat33_t_R_yzw[2][0] = -sr;
        mat33_t_R_yzw[2][1] = -(cr * sp);
        mat33_t_R_yzw[2][2] = cr * cp;
#endif
        mat33_t_R_yzw[0][0] = cy * cr;
        mat33_t_R_yzw[0][1] = (cy * sr * sp + cp * sy);
        mat33_t_R_yzw[0][2] = sy * sp - cy * cp * sr;

        mat33_t_R_yzw[1][0] = -(cr * sy);
        mat33_t_R_yzw[1][1] = -(sy * sr * sp -cy * cp);
        mat33_t_R_yzw[1][2] = cp*sr*sy + sp*cy;

        mat33_t_R_yzw[2][0] = sr;
        mat33_t_R_yzw[2][1] = -(cr * sp);
        mat33_t_R_yzw[2][2] = cr * cp;

        const float Hx = mat33_t_R_yzw[0][0];
        const float My = mat33_t_R_yzw[1][1];
        const float Az = mat33_t_R_yzw[2][2];

        quat[0] = sqrtf(clamp(Hx - My - Az + 1) * 0.25f);
        quat[1] = sqrtf(clamp(-Hx + My - Az + 1) * 0.25f);
        quat[2] = sqrtf(clamp(-Hx - My + Az + 1) * 0.25f);
        quat[3] = sqrtf(clamp(Hx + My + Az + 1) * 0.25f);
        quat[0] = copysignf(quat[0], mat33_t_R_yzw[2][1] - mat33_t_R_yzw[1][2]);
        quat[1] = copysignf(quat[1], mat33_t_R_yzw[0][2] - mat33_t_R_yzw[2][0]);
        quat[2] = copysignf(quat[2], mat33_t_R_yzw[1][0] - mat33_t_R_yzw[0][1]);
    }
#endif
}
#endif
#if 0
void qst_fusion_get_euler(float euler[3],int mode)
{
    if(mode == 0)    // 9axis
        qst_fusion_9axis_angle(euler);
    else if(mode == 1)    //    a+g
        qst_fusion_nomag_angle(euler);
    else if(mode == 2)    // a+m
        qst_fusion_nogyro_angle(euler);
}
#endif

